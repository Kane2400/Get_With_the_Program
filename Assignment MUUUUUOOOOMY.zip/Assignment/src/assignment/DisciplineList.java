package assignment;

/**
 *
 * @author B00716828
 */
import java.io.*;
import java.util.*;

public class DisciplineList {

    private ArrayList<Discipline> disArrayList;
    private ReadAndWriteDiscipline readWriteDiscipline;    
   
    public DisciplineList() 
    {
        disArrayList = new ArrayList<>();
        readWriteDiscipline = new ReadAndWriteDiscipline();
    }

    public void addDiscipline(String name, String desc) 
    {
        Discipline newDis = new Discipline(name, desc);
        disArrayList.add(newDis);
        readWriteDiscipline.writeDiscipline(disArrayList);
    }

    public void removeDiscipline(int index) 
    {
        disArrayList.remove(index);
        readWriteDiscipline.writeDiscipline(disArrayList);
    }

    public ArrayList<Discipline> getDisciplineList() 
    {
        disArrayList  = readWriteDiscipline.readDiscipline(disArrayList);
        return disArrayList;
    }
}
