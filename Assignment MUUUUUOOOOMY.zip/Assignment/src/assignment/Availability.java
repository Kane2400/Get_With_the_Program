package assignment;

import java.text.*;
import java.util.*;
import javax.swing.JOptionPane;

/**
 *
 * @author Jonny
 */
public class Availability {

    private static String[] doctorNames;
    private final String[] daysOfTheWeek = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
    private final int NUM_DAYS = 7;
    private String[][] daysRelevant;
    private int numDoctors;
    private String[][] sunday, monday, tuesday, wednesday, thursday, friday, saturday;
    private ReadTimetable readTime = new ReadTimetable();
    private ArrayList<String> relevantST, relevantET;

    public Availability() {

        readTime.readFromFile();
        int dayNum = 0;
        ArrayList<String> doctorNamesList = readTime.getDocNames();
        doctorNames = new String[doctorNamesList.size()];
        for (int k = 0; k < doctorNames.length; k++) {
            doctorNames[k] = doctorNamesList.get(k);
        }
        ArrayList<String> startTime = readTime.getStartTimes();
        ArrayList<String> endTime = readTime.getEndTimes();
        for (int i = 0; i < daysOfTheWeek.length; i++) {
            if (getDay().equals(daysOfTheWeek[i])) {
                dayNum = i;
                break;
            }
        }
        daysRelevant = new String[startTime.size()][2];
        int position = dayNum;
        for (int j = 0; j < doctorNames.length; j++) {
            daysRelevant[j][0] = startTime.get(position);
            daysRelevant[j][1] = endTime.get(position);
            position += NUM_DAYS;
        }
        numDoctors = doctorNames.length;
    }

    private int getDocNum(String docname) 
    {
        for (int docNum = 0; docNum < numDoctors; docNum++) 
        {
            if (doctorNames[docNum].equals(docname)) 
            {
                return docNum;
            }
        }
        return numDoctors;
    }
    
    private String parseTime(int docNum)
    {
        Date date = new Date();
        DateFormat timeFormat = new SimpleDateFormat("HH:mm");
        try 
        {
            if (timeFormat.parse(getTime()).after(timeFormat.parse(daysRelevant[docNum][0]))
                    && timeFormat.parse(timeFormat.format(date)).before(timeFormat.parse(daysRelevant[docNum][1]))) 
            {
                return "yes";
            }
        } catch (ParseException e) 
        {
            System.out.println("Error when Parsing");
        }
        return "no";
    }
    
    public String getAvailability(String docname) 
    {
        int docNum = getDocNum(docname);
        if (docNum < numDoctors && docNum >= 0)
        {
            return this.parseTime(docNum);
        }
        return "Error";
    }

    private String getTime() 
    { // returns the current time to be compared to those stored in the availability update file
        DateFormat timeFormat = new SimpleDateFormat("HH:mm");
        Date time = new Date();
        return timeFormat.format(time);
    }

    private String getDay() { // returns the current day
        DateFormat dayFormat = new SimpleDateFormat("EEEE");
        Date day = new Date();
        return dayFormat.format(day);
    }
    
    private void declareDaysOfTheWeek(ArrayList<String> docNames)
    {
        sunday = new String[docNames.size()][2];
        monday = new String[docNames.size()][2];
        tuesday = new String[docNames.size()][2];
        wednesday = new String[docNames.size()][2];
        thursday = new String[docNames.size()][2];
        friday = new String[docNames.size()][2];
        saturday = new String[docNames.size()][2];
    }
    
    private void initialiseDaysOfTheWeek(ArrayList<Doctor> doctorsList, ArrayList<String> startTimes, ArrayList<String> endTimes)
    {     
        int index = 0;
        for (int i = 0; i < doctorsList.size(); i++) 
        {
            sunday[i][0] = startTimes.get(index);
            sunday[i][1] = endTimes.get(index);     index++; 
            monday[i][0] = startTimes.get(index);
            monday[i][1] = endTimes.get(index);     index++; 
            tuesday[i][0] = startTimes.get(index);
            tuesday[i][1] = endTimes.get(index);    index++; 
            wednesday[i][0] = startTimes.get(index);
            wednesday[i][1] = endTimes.get(index);  index++; 
            thursday[i][0] = startTimes.get(index);
            thursday[i][1] = endTimes.get(index);   index++; 
            friday[i][0] = startTimes.get(index);
            friday[i][1] = endTimes.get(index);     index++; 
            saturday[i][0] = startTimes.get(index);
            saturday[i][1] = endTimes.get(index);   index++; 
        }
    }
    
    private void relevantStartAndEndTimes(int dayNum, int i)
    {
        switch (dayNum) 
        {
            case 0:
                relevantST.add(sunday[i][0]);
                relevantET.add(sunday[i][1]);
                break;
            case 1:
                relevantST.add(monday[i][0]);
                relevantET.add(monday[i][1]);
                break;
            case 2:
                relevantST.add(tuesday[i][0]);
                relevantET.add(tuesday[i][1]);
                break;
            case 3:
                relevantST.add(wednesday[i][0]);
                relevantET.add(wednesday[i][1]);
                break;
            case 4:
                relevantST.add(thursday[i][0]);
                relevantET.add(thursday[i][1]);
                break;
            case 5:
                relevantST.add(friday[i][0]);
                relevantET.add(friday[i][1]);
                break;
            case 6:
                relevantST.add(saturday[i][0]);
                relevantET.add(saturday[i][1]);
                break;
            default:
                break;
        }
    }

    public void getReport(ArrayList<Doctor> doctorsList, String medDisc) 
    {
        String output = "";
        ArrayList<String> docNamesArrayList, startTimes, endTimes;
        docNamesArrayList = readTime.getDocNames();
        startTimes = readTime.getStartTimes();
        endTimes = readTime.getEndTimes();
        this.declareDaysOfTheWeek(docNamesArrayList);
        this.initialiseDaysOfTheWeek(doctorsList, startTimes, endTimes);

        for (int dayNum = 0; dayNum < NUM_DAYS; dayNum++) 
        {
            ArrayList<String> relevantST, relevantET;
            relevantST = new ArrayList<>();
            relevantET = new ArrayList<>();
            for (int i = 0; i < docNamesArrayList.size(); i++) 
            {
                for (int j = 0; j < doctorsList.size(); j++) 
                {
                    if (docNamesArrayList.get(i).equals(doctorsList.get(j).getName())) 
                    {
                        this.relevantStartAndEndTimes(dayNum, i);
                    }
                }
            }
            String[] orderedST, orderedET;
            orderedST = new String[relevantST.size()];
            orderedET = new String[relevantET.size()];
            for (int i = 0; i < relevantST.size(); i++) {
                orderedST[i] = relevantST.get(i);
                orderedET[i] = relevantET.get(i);
            }
            ArrayList<String> orderedStartTimes, orderedEndTimes;
            orderedStartTimes = new ArrayList<>();
            orderedEndTimes = new ArrayList<>();

            String[][] sortedArrays = this.sort(orderedST, orderedET);
            int arrayIndex = 0;
            for (int i = 0; i < sortedArrays.length; i++) {
                orderedStartTimes.add(sortedArrays[i][0]);
                orderedEndTimes.add(sortedArrays[i][1]);
                if (orderedStartTimes.get(arrayIndex).equals(orderedEndTimes.get(arrayIndex))) {
                    orderedStartTimes.remove(arrayIndex);
                    orderedEndTimes.remove(arrayIndex);
                    arrayIndex--;
                }
                arrayIndex++;
            }
            output += daysOfTheWeek[dayNum] + "\n";
            String time = "00:00";
            DateFormat timeFormat = new SimpleDateFormat("HH:mm");
            if (orderedStartTimes.isEmpty()) {
                output += "00:00 - 23:59\n";
            } else {
                for (int i = 0; i < orderedStartTimes.size(); i++) {
                    try {
                        if (timeFormat.parse(orderedStartTimes.get(i)).after(timeFormat.parse(time))) {
                            output += time + " - " + orderedStartTimes.get(i) + "\n";
                            time = orderedEndTimes.get(i);
                        } else if (timeFormat.parse(orderedEndTimes.get(i)).after(timeFormat.parse(time))) {
                            time = orderedStartTimes.get(i);
                        }
                    } catch (ParseException e) {

                    }
                }
                output += time + " - 23:59\n";

            }
            output += "\n";

        }
        JOptionPane.showMessageDialog(null, output, "Report for " + medDisc + " discipline", JOptionPane.INFORMATION_MESSAGE);
    }

    private String[][] sort(String[] toBeSorted, String[] switchAlongWith) {
        try {
            DateFormat timeFormat = new SimpleDateFormat("HH:mm");
            int i, index, size;
            String currentSort, currentSwitch;
            size = toBeSorted.length;
            for (i = 1; i < size; i++) {
                currentSort = toBeSorted[i];
                currentSwitch = switchAlongWith[i];
                index = i;
                while ((index > 0) && (timeFormat.parse(toBeSorted[index - 1]).after(timeFormat.parse(currentSort)))) {
                    toBeSorted[index] = toBeSorted[index - 1];
                    switchAlongWith[index] = switchAlongWith[index - 1];
                    index--;
                }
                toBeSorted[index] = currentSort;
                switchAlongWith[index] = currentSwitch;
            }
        } catch (ParseException e) {
        }
        String[][] toBeReturned = new String[toBeSorted.length][2];
        for (int i = 0; i < toBeSorted.length; i++) {
            toBeReturned[i][0] = toBeSorted[i];
            toBeReturned[i][1] = switchAlongWith[i];
        }
        return toBeReturned;
    }
}
