package assignment;

/**
 *
 * @author B00718269
 */
import java.io.*;
import java.util.*;

public class DoctorList {

    //Doctor[] listOfDoc = new Doctor[10];
    private ArrayList<Doctor> docList = new ArrayList<>();
    private Scanner readin;
    private File doctorInput = new File("doctorInput.txt");
    private ReadAndWriteDoctor readWriteDoctor = new ReadAndWriteDoctor();    

    public DoctorList() 
    {
    }

    public void addDoctor(String name, String address, String prefContact, String conID, String medDisc, String lastCert) 
    {
        if (lastCert.equals("")) 
        {
            lastCert = "N/A";
        }
        Doctor newDoc = new Doctor(name, address, prefContact, conID, medDisc, lastCert);
        docList.add(newDoc);
        this.writeToFile(docList);
    }

    public void removeDoctor(int index) 
    {
        docList.remove(index);
        this.writeToFile(docList);
    }

    public ArrayList<Doctor> getDoctorList() 
    {
        docList = readWriteDoctor.readDoctor(docList);
        return docList;
    }
    
    public void writeToFile(ArrayList<Doctor> docList) 
    {
        readWriteDoctor = new ReadAndWriteDoctor();
        readWriteDoctor.writeDoctor(docList);
    }
}
