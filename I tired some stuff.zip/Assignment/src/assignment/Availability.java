package assignment;

import java.text.*;
import java.util.*;
import javax.swing.JOptionPane;

/**
 *
 * @author Jonny
 */
public class Availability {

    private static String[] doctors;
    private final String[] daysOfTheWeek = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
    private final int NUM_DAYS = 7;
    private String[][] daysRelevant;
    private int numDoctors;
    ReadTimetable readTime = new ReadTimetable();
    private int index;
    private String[][][] daysOfTheWeekTimes;

    public Availability() {

        readTime.readFromFile();
        int dayNum = 0;
        ArrayList<String> dn = readTime.getDocNames();
        doctors = new String[dn.size()];
        for (int k = 0; k < doctors.length; k++) {
            doctors[k] = dn.get(k);
        }
        ArrayList<String> st = readTime.getStartTimes();
        ArrayList<String> et = readTime.getEndTimes();
        for (int i = 0; i < daysOfTheWeek.length; i++) {
            if (getDay().equals(daysOfTheWeek[i])) {
                dayNum = i;
                break;
            }
        }
        daysRelevant = new String[st.size()][2];
        int position = dayNum;
        for (int j = 0; j < dn.size(); j++) {
            daysRelevant[j][0] = st.get(position);
            daysRelevant[j][1] = et.get(position);
            position += NUM_DAYS;
        }
        numDoctors = dn.size();

    }

    private String parseTime(int docNum) {
        Date date = new Date();
        DateFormat timeFormat = new SimpleDateFormat("HH:mm");
        try {
            if (timeFormat.parse(getTime()).after(timeFormat.parse(daysRelevant[docNum][0]))
                    && timeFormat.parse(timeFormat.format(date)).before(timeFormat.parse(daysRelevant[docNum][1]))) {
                return "yes";
            }
        } catch (ParseException e) {
            System.out.println("Error when Parsing");
        }
        return "no";
    }

    public String getAvailability(String docname) {
        int docNum = getDocNum(docname);
        if (docNum < numDoctors && docNum >= 0) {
            return this.parseTime(docNum);
        }
        return "Error";
    }

    private int getDocNum(String docname) {
        for (int docNum = 0; docNum < numDoctors; docNum++) {
            if (doctors[docNum].equals(docname)) {
                return docNum;
            }
        }
        return numDoctors;
    }

    private String getTime() { // returns the current time to be compared to those stored in the availability update file
        DateFormat timeFormat = new SimpleDateFormat("HH:mm");
        Date time = new Date();
        return timeFormat.format(time);
    }

    private String getDay() { // returns the current day
        DateFormat dayFormat = new SimpleDateFormat("EEEE");
        Date day = new Date();
        return dayFormat.format(day);
    }

    private void addTimesToDaysOfTheWeek(ArrayList<String> startTimes,
            ArrayList<String> endTimes, int docNum) {
        for (int i = 0; i < NUM_DAYS; i++) {
            daysOfTheWeekTimes[i][docNum][0] = startTimes.get(index);
            daysOfTheWeekTimes[i][docNum][1] = endTimes.get(index);
            index++;
        }
    }

    private String addTimesToOutputString(ArrayList<String> orderedStartTimes, ArrayList<String> orderedEndTimes) {
        String output = "";
        String time = "00:00";
        DateFormat timeFormat = new SimpleDateFormat("HH:mm");
        if (orderedStartTimes.isEmpty()) {
            output += "00:00 - 23:59\n";
        } else {
            for (int i = 0; i < orderedStartTimes.size(); i++) {
                try {
                    if (timeFormat.parse(orderedStartTimes.get(i)).after(timeFormat.parse(time))) {
                        output += time + " - " + orderedStartTimes.get(i) + "\n";
                        time = orderedEndTimes.get(i);
                    } else if (timeFormat.parse(orderedEndTimes.get(i)).after(timeFormat.parse(time))) {
                        time = orderedStartTimes.get(i);
                    }
                } catch (ParseException e) {
                }
            }
            output += time + " - 23:59\n";
        }
        return output;
    }

    public void getReport(ArrayList<Doctor> doctorsList, String medDisc) {
        String output = "";
        ArrayList<String> docNames, startTimes, endTimes;
        docNames = readTime.getDocNames();
        startTimes = readTime.getStartTimes();
        endTimes = readTime.getEndTimes();
        daysOfTheWeekTimes = new String[7][docNames.size()][2];
        index = 0;
        for (int i = 0; i < docNames.size(); i++) {
            addTimesToDaysOfTheWeek(startTimes, endTimes, i);
        }
        for (int dayNum = 0; dayNum < NUM_DAYS; dayNum++) {
            ArrayList<String> relevantST, relevantET;
            relevantST = new ArrayList<>();
            relevantET = new ArrayList<>();
            for (int i = 0; i < docNames.size(); i++) {
                for (int j = 0; j < doctorsList.size(); j++) {
                    if (docNames.get(i).equals(doctorsList.get(j).getName())) {
                        relevantST.add(daysOfTheWeekTimes[dayNum][i][0]);
                        relevantET.add(daysOfTheWeekTimes[dayNum][i][1]);
                    }
                }
            }
            String[] orderedST, orderedET;
            orderedST = new String[relevantST.size()];
            orderedET = new String[relevantET.size()];
            for (int i = 0; i < relevantST.size(); i++) {
                orderedST[i] = relevantST.get(i);
                orderedET[i] = relevantET.get(i);
            }
            ArrayList<String> orderedStartTimes, orderedEndTimes;
            orderedStartTimes = new ArrayList<>();
            orderedEndTimes = new ArrayList<>();
            String[][] sortedArrays = this.sort(orderedST, orderedET);
            int arrayIndex = 0;
            for (int i = 0; i < sortedArrays.length; i++) {
                orderedStartTimes.add(sortedArrays[i][0]);
                orderedEndTimes.add(sortedArrays[i][1]);
                if (orderedStartTimes.get(arrayIndex).equals(orderedEndTimes.get(arrayIndex))) {
                    orderedStartTimes.remove(arrayIndex);
                    orderedEndTimes.remove(arrayIndex);
                    arrayIndex--;
                }
                arrayIndex++;
            }
            output += daysOfTheWeek[dayNum] + "\n";
            output += addTimesToOutputString(orderedStartTimes, orderedEndTimes);
            output += "\n";
        }
        JOptionPane.showMessageDialog(null, output, "Report for " + medDisc + " discipline", JOptionPane.INFORMATION_MESSAGE);
    }

    private String[][] sort(String[] toBeSorted, String[] switchAlongWith) {
        try {
            DateFormat timeFormat = new SimpleDateFormat("HH:mm");
            int i, index, size;
            String currentSort, currentSwitch;
            size = toBeSorted.length;
            for (i = 1; i < size; i++) {
                currentSort = toBeSorted[i];
                currentSwitch = switchAlongWith[i];
                index = i;
                while ((index > 0) && (timeFormat.parse(toBeSorted[index - 1]).after(timeFormat.parse(currentSort)))) {
                    toBeSorted[index] = toBeSorted[index - 1];
                    switchAlongWith[index] = switchAlongWith[index - 1];
                    index--;
                }
                toBeSorted[index] = currentSort;
                switchAlongWith[index] = currentSwitch;
            }
        } catch (ParseException e) {
        }
        String[][] toBeReturned = new String[toBeSorted.length][2];
        for (int i = 0; i < toBeSorted.length; i++) {
            toBeReturned[i][0] = toBeSorted[i];
            toBeReturned[i][1] = switchAlongWith[i];
        }
        return toBeReturned;
    }

}
