import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class MedicalResourceSystem {

    public static void main(String[] args) {

        //to get list of doctors
        DoctorList docList = new DoctorList();
        ArrayList<Doctor> doctors = docList.getArrayList();
        String[] docNames = new String[doctors.size()];
        for (int i = 0; i < doctors.size(); i++) {
            docNames[i] = doctors.get(i).getName();
            System.out.println(docNames[i]);
        }

        //to add list of doctors to gui
        String[] doctorsOutput = new String[doctors.size()];
        for (int i = 0; i < doctors.size(); i++) {
            doctorsOutput[i] = doctors.get(i).getAll();

            //JLabel label = new JLabel(doctorsOutput[i]");
            //add(label);
            //or
            //JLabel label = new JLabel(doctors.get(i).getAll());
            //add(label);
        //}

        //to display availabilities by medical discipline
        String medDisString = "Hematology";
        Availability available = new Availability();
        for (int j = 0; j < docNames.length; j++) {
            if (doctors.get(j).getDiscipline().equals(medDisString)) {
            //System.out.println(docNames[j]);
                String isAvailable = available.getAvailability(docNames[j]);
                if (isAvailable.equals("yes")) {
                    System.out.println("green");
                    // display doctor's name + green
                } else if (isAvailable.equals("no")) {
                    System.out.println("red");
                    // display doctor's name + red
                } else {
                    System.out.println("grey");
                    // display doctor's name + grey
                }
            }

        }

        //to add doctor
        JTextField nameField = new JTextField();
        JTextField addressField = new JTextField();
        JTextField contactMeansField = new JTextField();
        JTextField contactIDField = new JTextField();
        JTextField medDiscField = new JTextField();
        JTextField lastCertField = new JTextField();
        Object[] message = {
            "Enter doctor details",
            "Name:", nameField,
            "Address:", addressField,
            "Preferred Contact Means:", contactMeansField,
            "Contact ID:", contactIDField,
            "Medical Discipline:", medDiscField,
            "Date of Last Certification:", lastCertField};
        int option = JOptionPane.showConfirmDialog(null, message, "Add Doctor", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            //getText() calls
        }
        //docList.addDoctor(nameField.getText(), addressField.getText(), contactField.getText(), contactIdField.getText(), disciplineField.getText(), certField.getText());
        docList.writeToFile(doctors);

    }

}
}
