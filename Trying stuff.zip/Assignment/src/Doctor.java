import java.util.Date;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author B00718269
 */
public class Doctor 
{

    private String docName;
    private String contactAddress;
    private String prefContactMeans;
    private String contactID;
    private String medDiscipline;
    private String lastCertification;

    public Doctor(String name, String address, String meansContact, String contact, String discipline) 
    {
        this.docName = name;
        this.contactAddress = address;
        this.prefContactMeans = meansContact;
        this.contactID = contact;
        this.medDiscipline = discipline;
        this.lastCertification = "N/A";

    }

    public Doctor(String name, String address, String meansContact, String contact, String discipline, String lastCert) 
    {
        this.docName = name;
        this.contactAddress = address;
        this.prefContactMeans = meansContact;
        this.contactID = contact;
        this.medDiscipline = discipline;
        this.lastCertification = lastCert;

    }

    public String getName() 
    {
        return this.docName;
    }

    public void setName(String name) 
    {
        this.docName = name;
    }

    public String getAddress() 
    {
        return this.contactAddress;
    }

    public void setAddress(String address) 
    {
        this.contactAddress = address;
    }

    public String getContactMeans() 
    {
        return this.prefContactMeans;
    }

    public void setContactMeans(String prefContact) 
    {
        this.prefContactMeans = prefContact;
    }

    public String getContactID() 
    {
        return this.contactID;
    }

    public void setContactID(String conID) 
    {
        this.contactID = conID;
    }

    public String getDiscipline() 
    {
        return this.medDiscipline;
    }

    public void setDiscipline(String medDisc) 
    {
        this.medDiscipline = medDisc;
    }

    public String getLastCert() 
    {
        return this.lastCertification;
    }
    
    public void setLastCert(String lastCert) 
    {
        this.lastCertification = lastCert;
    }

    public String getAll() 
    {
        return this.docName + "\t" 
                + this.contactAddress + "\t"
                + this.prefContactMeans + "\t"
                + this.contactID + "\t"
                + this.medDiscipline + "\t"
                + this.lastCertification;
    }
}
