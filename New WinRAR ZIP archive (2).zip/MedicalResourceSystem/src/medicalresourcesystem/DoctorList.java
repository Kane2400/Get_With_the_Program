package medicalresourcesystem;

/**
 *
 * @author B00718269
 */
import java.io.*;
import java.util.*;

public class DoctorList {

    //Doctor[] listOfDoc = new Doctor[10];
    private ArrayList<Doctor> docList = new ArrayList<>();
    private Scanner readin;
    private File doctorInput = new File("doctorInput.txt");
    private ReadAndWriteDoctor rwd = new ReadAndWriteDoctor();
    
    

    public DoctorList() 
    {
        /* for(int i = 0; i < listOfDoc.length; i++ )
       {
         //  listofDoc[i] =                             //may be replaced by populateList
       }*/
    }

    public void addDoctor(String name, String address, String prefContact, String conID, String medDisc, String lastCert) 
    {
        if (lastCert.equals("")) 
        {
            lastCert = "N/A";
        }
        Doctor newDoc = new Doctor(name, address, prefContact, conID, medDisc, lastCert);
        docList.add(newDoc);
    }

    public void removeDoctor(int index) 
    {
        docList.remove(index);
    }

    public void populateList() throws FileNotFoundException, IOException 
    {
        readin = new Scanner(doctorInput);                                                                                                                                          
        while (readin.hasNext()) 
        {
            //listofDoc.
        }

    }
    public ArrayList<Doctor> getArrayList() 
    {
        docList = rwd.readDoctor(docList);
        return docList;
    }
    
    public void writeToFile(ArrayList<Doctor> docList) 
    {
        rwd = new ReadAndWriteDoctor();
        rwd.writeDoctor(docList);
    }

    /*public void restackAfterRemoveDoc(int numRemove) {
        for (int i = numRemove; i < 9; i++) {
            Doctor temp;
            temp = listOfDoc[i];
            listOfDoc[i - 1] = temp;

        }
        
        
    }*/

}
