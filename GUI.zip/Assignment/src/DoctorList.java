/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author B00718269
 */

import java.io.*;
import java.util.*;

public class DoctorList
{
    Doctor[] listOfDoc = new Doctor[10];
    ArrayList<String> docList = new ArrayList<String>();
    Scanner readin;
    File doctorInput = new File("doctorInput.txt");
    
    public DoctorList()
    {
     /* for(int i = 0; i < listOfDoc.length; i++ )
       {
         //  listofDoc[i] =                             //may be replaced by populateList
       }*/
    }
    
    public void addDoctor()
    {
        
    }
    
    public void removeDoctor()
    {
        
    }
    
    public void populateList() throws FileNotFoundException, IOException
    {
        readin = new Scanner(doctorInput);
        while (readin.hasNext())
        {
            //listofDoc.
                    
        }
        
    }
    
    public void restackAfterRemoveDoc(int numRemove)
    {
        for(int i = numRemove; i < 9; i++)
                    {
                        Doctor temp;
                        temp = listOfDoc[i];
                        listOfDoc[i-1] = temp;
                        
                    }
    }
    
}
