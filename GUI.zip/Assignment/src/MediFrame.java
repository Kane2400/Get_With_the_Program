import javax.swing.*;
/**
 *
 * @author B00718269,B00718694
 */
public class MediFrame extends JFrame
{
    
    
    
    
    
    
    
    
    
    
    
    
    
}
