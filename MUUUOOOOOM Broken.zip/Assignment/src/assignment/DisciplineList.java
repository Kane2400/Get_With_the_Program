package assignment;

/**
 *
 * @author B00716828
 */
import java.io.*;
import java.util.*;

public class DisciplineList {

    private ArrayList<Discipline> disArrayList = new ArrayList<>(); 
    private ReadAndWriteDiscipline readWriteDiscipline =  new ReadAndWriteDiscipline();
   
    public DisciplineList() 
    {
    }

    public void addDiscipline(String name, String desc) 
    {
        Discipline newDis = new Discipline(name, desc);
        disArrayList.add(newDis);
        readWriteDiscipline.writeDiscipline(disArrayList);
    }

    public void removeDiscipline(int index) 
    {
        disArrayList.remove(index);
        readWriteDiscipline.writeDiscipline(disArrayList);
    }

    public ArrayList<Discipline> getDisciplineList() 
    {
        ArrayList<Discipline> arrayList = new ArrayList<>();
        arrayList = readWriteDiscipline.readDiscipline(arrayList);
        disArrayList = arrayList;
        return arrayList;
    }
}
