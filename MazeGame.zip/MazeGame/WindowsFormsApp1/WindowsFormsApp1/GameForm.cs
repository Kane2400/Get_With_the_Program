﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApp1
{
    public partial class GameForm : Form
    {


        private const int CellSize = 20;

        private MapCell[,] map;

        private Maze_Hunter hunter = new Maze_Hunter();

        private Random rand = new Random();

        public GameForm()
        {
            InitializeComponent();
            if (Form1.startTimer == true)
            {
                timer1.Enabled = true;
                timer2.Enabled = true;
            }
        }

     

        private MapCell[,] CreateArray(string mapFile)
        {
            int numberRows = 0;
            int numberColumns = 0;

            string line = null;

            try
            {
                StreamReader mapData = new StreamReader(mapFile);

                line = mapData.ReadLine();
                numberColumns = line.Length;

                while (line != null)
                {
                    numberRows++;
                    line = mapData.ReadLine();
                }

                mapData.Close();

            }
            catch (System.IO.IOException e)
            {

                MessageBox.Show(e.Message);
            }

            MapCell[,] map = new MapCell[numberColumns, numberRows];

            try
            {
                StreamReader mapData = new StreamReader(mapFile);

                line = mapData.ReadLine();

                int rowIndex = 0;

                while (line != null)
                {
                    for (int columnIndex = 0; columnIndex < line.Length; columnIndex++)
                    {
                        map[columnIndex, rowIndex] = new MapCell(columnIndex, rowIndex, line[columnIndex]);

                    }

                    rowIndex++;

                    line = mapData.ReadLine();
                }

                mapData.Close();
            }
            catch (System.IO.IOException e)
            {

                MessageBox.Show(e.Message);
            }

            return map;
        }

        private void GameForm_Load(object sender, EventArgs e) // On Load the form will automatically load the map
        {
            map = CreateArray("..\\..\\Resources\\Map\\Level.txt"); // URL Path for the Map

            mazePictureBox.Width = map.GetLength(0) * CellSize;
            mazePictureBox.Height = map.GetLength(1) * CellSize;
        }




        private void mazePictureBox_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;        

            for (int row = 0; row < map.GetLength(0); row++)
                for (int column = 0; column < map.GetLength(1); column++)
                {
                    map[row, column].DrawBackground(g);
                }

            hunter.Draw(g);
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            switch (rand.Next(4))
            {
                case 0:
                    hunter.MoveHunterUp();
                    break;

                case 1:
                    hunter.MoveHunterDown();
                    break;

                case 2:
                    hunter.MoveHunterRight();
                    break;

                case 3:
                    hunter.MoveHunterLeft();
                    break;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            mazePictureBox.Invalidate();
        }
    }
}
