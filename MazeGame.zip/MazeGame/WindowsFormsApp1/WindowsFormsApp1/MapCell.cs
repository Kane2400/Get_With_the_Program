﻿using System.Drawing;

namespace WindowsFormsApp1
{

    
    public class MapCell
    {
        const int SizeOfCell = 20; //cell dimension in pixels
        private int x, y;
        private char type;
        private bool isVisible = true;

        //Constructor
        public MapCell(int x, int y, char type)
        {
            this.type = type;
            this.x = x;
            this.y = y;
        }

        //Set cell as visited (no pill inside it)
        public bool IsVisible
        {
            get
            {
                return isVisible;
            }

            set
            {
                isVisible = value;
            }
        }

        public char CellType
        {
            get { return type; }
            set { type = value; }
        }


        //draw the cell 
        public virtual void DrawBackground(Graphics g)
        {

            switch (type)
            {
                case 'w'://wall
                    g.FillRectangle(Brushes.Black, x * SizeOfCell, y * SizeOfCell, SizeOfCell, SizeOfCell);
                    break;
                case 'p'://path
                    g.FillRectangle(Brushes.White, x * SizeOfCell, y * SizeOfCell, SizeOfCell, SizeOfCell);
                    break;
                case 's'://starting position
                    g.FillRectangle(Brushes.Blue, x * SizeOfCell, y * SizeOfCell, SizeOfCell, SizeOfCell);
                    g.DrawString("S", new Font("Arial", 12, FontStyle.Bold), new SolidBrush(Color.Red), new Point(x * SizeOfCell, y * SizeOfCell));
                    break;
                case 'f'://finishing line
                    g.FillRectangle(Brushes.Blue, x * SizeOfCell, y * SizeOfCell, SizeOfCell, SizeOfCell);
                    g.DrawString("F", new Font("Arial", 12, FontStyle.Bold), new SolidBrush(Color.Red), new Point(x * SizeOfCell, y * SizeOfCell));
                    break;
                case 'g'://guard position
                    g.FillRectangle(Brushes.Blue, x * SizeOfCell, y * SizeOfCell, SizeOfCell, SizeOfCell);
                    g.DrawString("G", new Font("Arial", 12, FontStyle.Bold), new SolidBrush(Color.Red), new Point(x * SizeOfCell, y * SizeOfCell));
                    break;
                default:
                    break;
            }
        }
    }
  }

