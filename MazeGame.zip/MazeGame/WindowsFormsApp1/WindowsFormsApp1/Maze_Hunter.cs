﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public class Maze_Hunter
    {
        enum direction {UP = 20, DOWN = -20, LEFT = -20, RIGHT = 20 }
        //private PictureBox HunterPB = new PictureBox();

        private int hunterWidth = 20;
        private int hunterHeight = 20;

        private int coordX = 100;
        private int coordY = 100;

        public int CoordX
        {
            get { return coordX; }
            set { coordX = value; }
        }

        public int CoordY
        {
            get { return coordY; }
            set { coordY = value; }
        }

        public int HunterWidth
        {
            get { return hunterWidth; }
            set { hunterWidth = value; }
        }

        public int HunterHeight
        {   
            get { return hunterHeight; }
            set { hunterHeight = value; }
        }

        //get boundary
        internal Rectangle GetBoundingBox()
        {
            return new Rectangle(CoordX, CoordY, HunterWidth, HunterHeight);
        }

        public void Draw(Graphics g)
        {
            //draw the hunter as the yellow rectangle
            g.FillRectangle(new SolidBrush(Color.Red), CoordX, CoordY, HunterWidth, HunterHeight);
        }  
            
        
        //Move hunter
        public void MoveHunterUp()
        {
           coordY += (int)direction.UP;
        }

        public void MoveHunterDown()
        {
            coordY += (int)direction.DOWN;
        }

        public void MoveHunterRight()
        {
            coordX += (int)direction.RIGHT;
        }

        public void MoveHunterLeft()
        {
             coordX += (int)direction.LEFT;
        }
    }
}