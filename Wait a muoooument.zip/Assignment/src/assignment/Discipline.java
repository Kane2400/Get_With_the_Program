package assignment;

/**
 *
 * @author Jonny
 */
public class Discipline {
    private String disName;
    private String description;

    public Discipline(String name, String desc) 
    {
        this.disName = name;
        this.description = desc;
    }

    public String getName() 
    {
        return this.disName;
    }

    public void setName(String name) 
    {
        this.disName = name;
    }

    public String getDescription() 
    {
        return this.description;
    }

    public void setDescription(String desc) 
    {
        this.description = desc;
    }
}
