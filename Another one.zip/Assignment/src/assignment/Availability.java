package assignment;

import java.text.*;
import java.util.*;
import javax.swing.JOptionPane;

/**
 *
 * @author Jonny
 */
public class Availability {

    private static String[] doctors;
    private final String[] daysOfTheWeek = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
    private final int NUM_DAYS = daysOfTheWeek.length;
    private String[][] daysRelevant;
    private int numDoctors;
    ReadTimetable rt = new ReadTimetable();

    public Availability() {

        rt.readFromFile();
        int dayNum = 0;
        ArrayList<String> dn = rt.getDocNames();
        doctors = new String[dn.size()];
        for (int k = 0; k < doctors.length; k++) {
            doctors[k] = dn.get(k);
        }
        ArrayList<String> st = rt.getStartTimes();
        ArrayList<String> et = rt.getEndTimes();
        for (int i = 0; i < daysOfTheWeek.length; i++) {
            if (getDay().equals(daysOfTheWeek[i])) {
                dayNum = i;
                break;
            }
        }
        daysRelevant = new String[st.size()][2];
        int position = dayNum;
        for (int j = 0; j < dn.size(); j++) {
            daysRelevant[j][0] = st.get(position);
            daysRelevant[j][1] = et.get(position);
            position += NUM_DAYS;
        }
        numDoctors = dn.size();

    }

    public String getAvailability(String docname) {
        int docNum = getDocNum(docname);
        if (docNum < numDoctors && docNum >= 0) {
            Date date = new Date();
            DateFormat timeFormat = new SimpleDateFormat("HH:mm");
            try {
                if (timeFormat.parse(getTime()).after(timeFormat.parse(daysRelevant[docNum][0]))
                        && timeFormat.parse(timeFormat.format(date)).before(timeFormat.parse(daysRelevant[docNum][1]))) {
                    // Currently available
                    return "yes";

                } else {
                    // Currently unavailable
                    return "no";
                }
            } catch (ParseException e) {
                // Something went wrong
            }
        }
        return "Error";
    }

    private int getDocNum(String docname) {
        for (int docNum = 0; docNum < numDoctors; docNum++) {
            if (doctors[docNum].equals(docname)) {
                return docNum;
            }
        }
        return numDoctors;
    }

    private String getTime() 
    { // returns the current time to be compared to those stored in the availability update file
        DateFormat timeFormat = new SimpleDateFormat("HH:mm");
        Date time = new Date();
        return timeFormat.format(time);
    }

    private String getDay() { // returns the current day
        DateFormat dayFormat = new SimpleDateFormat("EEEE");
        Date day = new Date();
        return dayFormat.format(day);
    }

    public void getReport(ArrayList<Doctor> doctorsList, String medDisc) {
        String output = "";
        ArrayList<String> docNames, startTimes, endTimes;
        docNames = rt.getDocNames();
        startTimes = rt.getStartTimes();
        endTimes = rt.getEndTimes();
        String[][] sunday, monday, tuesday, wednesday, thursday, friday, saturday;
        sunday = new String[docNames.size()][2];
        monday = new String[docNames.size()][2];
        tuesday = new String[docNames.size()][2];
        wednesday = new String[docNames.size()][2];
        thursday = new String[docNames.size()][2];
        friday = new String[docNames.size()][2];
        saturday = new String[docNames.size()][2];
        int muom = 0;
        for (int i = 0; i < docNames.size(); i++) {
            sunday[i][0] = startTimes.get(muom);
            sunday[i][1] = endTimes.get(muom);
            muom++;
            monday[i][0] = startTimes.get(muom);
            monday[i][1] = endTimes.get(muom);
            muom++;
            tuesday[i][0] = startTimes.get(muom);
            tuesday[i][1] = endTimes.get(muom);
            muom++;
            wednesday[i][0] = startTimes.get(muom);
            wednesday[i][1] = endTimes.get(muom);
            muom++;
            thursday[i][0] = startTimes.get(muom);
            thursday[i][1] = endTimes.get(muom);
            muom++;
            friday[i][0] = startTimes.get(muom);
            friday[i][1] = endTimes.get(muom);
            muom++;
            saturday[i][0] = startTimes.get(muom);
            saturday[i][1] = endTimes.get(muom);
            muom++;
        }

        for (int dayNum = 0; dayNum < NUM_DAYS; dayNum++) {
            ArrayList<String> relevantST, relevantET;
            relevantST = new ArrayList<>();
            relevantET = new ArrayList<>();
            for (int i = 0; i < docNames.size(); i++) {
                for (int j = 0; j < doctorsList.size(); j++) {
                    if (docNames.get(i).equals(doctorsList.get(j).getName())) {
                        switch (dayNum) {
                            case 0:
                                relevantST.add(sunday[i][0]);
                                relevantET.add(sunday[i][1]);
                                break;
                            case 1:
                                relevantST.add(monday[i][0]);
                                relevantET.add(monday[i][1]);
                                break;
                            case 2:
                                relevantST.add(tuesday[i][0]);
                                relevantET.add(tuesday[i][1]);
                                break;
                            case 3:
                                relevantST.add(wednesday[i][0]);
                                relevantET.add(wednesday[i][1]);
                                break;
                            case 4:
                                relevantST.add(thursday[i][0]);
                                relevantET.add(thursday[i][1]);
                                break;
                            case 5:
                                relevantST.add(friday[i][0]);
                                relevantET.add(friday[i][1]);
                                break;
                            case 6:
                                relevantST.add(saturday[i][0]);
                                relevantET.add(saturday[i][1]);
                                break;
                            default:
                                break;
                        }
                    }
                }
            }
            String[] orderedST, orderedET;
            orderedST = new String[relevantST.size()];
            orderedET = new String[relevantET.size()];
            for (int i = 0; i < relevantST.size(); i++) {
                orderedST[i] = relevantST.get(i);
                orderedET[i] = relevantET.get(i);
            }
            ArrayList<String> orderedStartTimes, orderedEndTimes;
            orderedStartTimes = new ArrayList<>();
            orderedEndTimes = new ArrayList<>();

            String[][] sortedArrays = this.sort(orderedST, orderedET);
            int arrayIndex = 0;
            for (int i = 0; i < sortedArrays.length; i++) {
                orderedStartTimes.add(sortedArrays[i][0]);
                orderedEndTimes.add(sortedArrays[i][1]);
                if (orderedStartTimes.get(arrayIndex).equals(orderedEndTimes.get(arrayIndex))) {
                    orderedStartTimes.remove(arrayIndex);
                    orderedEndTimes.remove(arrayIndex);
                    arrayIndex--;
                }
                arrayIndex++;
            }
            output += daysOfTheWeek[dayNum] + "\n";
            String time = "00:00";
            DateFormat timeFormat = new SimpleDateFormat("HH:mm");
            if (orderedStartTimes.size() == 0) {
                output += "00:00 - 23:59\n";
            } else {
                for (int i = 0; i < orderedStartTimes.size(); i++) {
                    try {
                        if (timeFormat.parse(orderedStartTimes.get(i)).after(timeFormat.parse(time))) {
                            output += time + " - " + orderedStartTimes.get(i) + "\n";
                            time = orderedEndTimes.get(i);
                        } else if (timeFormat.parse(orderedEndTimes.get(i)).after(timeFormat.parse(time))) {
                            time = orderedStartTimes.get(i);
                        }
                    } catch (ParseException e) {

                    }
                }
                output += time + " - 23:59\n";

            }
            output += "\n";

        }
        JOptionPane.showMessageDialog(null, output, "Report for " + medDisc + " discipline", JOptionPane.INFORMATION_MESSAGE);
    }

    private String[][] sort(String[] toBeSorted, String[] switchAlongWith) {
        try {
            DateFormat timeFormat = new SimpleDateFormat("HH:mm");
            int i, index, size;
            String currentSort, currentSwitch;
            size = toBeSorted.length;
            for (i = 1; i < size; i++) {
                currentSort = toBeSorted[i];
                currentSwitch = switchAlongWith[i];
                index = i;
                while ((index > 0) && (timeFormat.parse(toBeSorted[index - 1]).after(timeFormat.parse(currentSort)))) {
                    toBeSorted[index] = toBeSorted[index - 1];
                    switchAlongWith[index] = switchAlongWith[index - 1];
                    index--;
                }
                toBeSorted[index] = currentSort;
                switchAlongWith[index] = currentSwitch;
            }
        } catch (ParseException e) {
        }
        String[][] toBeReturned = new String[toBeSorted.length][2];
        for (int i = 0; i < toBeSorted.length; i++) {
            toBeReturned[i][0] = toBeSorted[i];
            toBeReturned[i][1] = switchAlongWith[i];
        }
        return toBeReturned;
    }

}
