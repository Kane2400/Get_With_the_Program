package assignment;

import java.text.*;
import java.util.*;
import javax.swing.JOptionPane;

/**
 *
 * @author Jonny
 */
public class Availability {

    private static String[] doctors;
    private final String[] daysOfTheWeek = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
    private final int NUM_DAYS = 7;
    private String[][] daysRelevant;
    private int numDoctors;
    private ReadTimetable readTime = new ReadTimetable();
    private int position;
    private String[][][] daysOfTheWeekTimes;

    public Availability() {

        readTime.readFromFile();
        int dayNum = 0;
        ArrayList<String> dn = readTime.getDocNames();
        doctors = new String[dn.size()];
        for (int k = 0; k < doctors.length; k++) {
            doctors[k] = dn.get(k);
        }
        ArrayList<String> st = readTime.getStartTimes();
        ArrayList<String> et = readTime.getEndTimes();
        for (int i = 0; i < daysOfTheWeek.length; i++) {
            if (getDay().equals(daysOfTheWeek[i])) {
                dayNum = i;
                break;
            }
        }
        daysRelevant = new String[st.size()][2];
        int position = dayNum;
        for (int j = 0; j < dn.size(); j++) {
            daysRelevant[j][0] = st.get(position);
            daysRelevant[j][1] = et.get(position);
            position += NUM_DAYS;
        }
        numDoctors = dn.size();
    }

    private String parseTime(int docNum) {
        Date date = new Date();
        DateFormat timeFormat = new SimpleDateFormat("HH:mm");
        try {
            if (timeFormat.parse(getTime()).after(timeFormat.parse(daysRelevant[docNum][0]))
                    && timeFormat.parse(timeFormat.format(date)).before(timeFormat.parse(daysRelevant[docNum][1]))) {
                return "yes";
            }
        } catch (ParseException e) {
            System.out.println("Error when Parsing");
        }
        return "no";
    }

    public String getAvailability(String docname) {
        int docNum = getDocNum(docname);
        if (docNum < numDoctors && docNum >= 0) {
            return this.parseTime(docNum);
        }
        return "Error";
    }

    private int getDocNum(String docname) {
        for (int docNum = 0; docNum < numDoctors; docNum++) {
            if (doctors[docNum].equals(docname)) {
                return docNum;
            }
        }
        return numDoctors;
    }

    private String getTime() { // returns the current time to be compared to those stored in the availability update file
        DateFormat timeFormat = new SimpleDateFormat("HH:mm");
        Date time = new Date();
        return timeFormat.format(time);
    }

    private String getDay() { // returns the current day
        DateFormat dayFormat = new SimpleDateFormat("EEEE");
        Date day = new Date();
        return dayFormat.format(day);
    }

    private String sortAndAdd(int dayNum, ArrayList<String> docNames, ArrayList<Doctor> doctorsList) {
        String output = "";
        ArrayList<String> relevantStartTimes, relevantEndTimes;
        ArrayList<ArrayList> relevantTimes = checkAllDoctors(dayNum, docNames, doctorsList);
        relevantStartTimes = relevantTimes.get(0);
        relevantEndTimes = relevantTimes.get(1);
        String[] toBeOrderedST, toBeOrderedET;
        toBeOrderedST = new String[relevantStartTimes.size()];
        toBeOrderedET = new String[relevantEndTimes.size()];
        for (int i = 0; i < relevantStartTimes.size(); i++) {
            toBeOrderedST[i] = relevantStartTimes.get(i);
            toBeOrderedET[i] = relevantEndTimes.get(i);
        }
        ArrayList<String> orderedStartTimes, orderedEndTimes;
        ArrayList<ArrayList> sortedTimes;
        sortedTimes = orderTimes(toBeOrderedST, toBeOrderedET);
        orderedStartTimes = sortedTimes.get(0);
        orderedEndTimes = sortedTimes.get(1);
        output += daysOfTheWeek[dayNum] + "\n";
        output += addTimesToOutputString(orderedStartTimes, orderedEndTimes);
        output += "\n";
        return output;
    }

    private void addTimesToDaysOfTheWeek(ArrayList<String> startTimes,
            ArrayList<String> endTimes, int docNum) {
        for (int i = 0; i < NUM_DAYS; i++) {
            daysOfTheWeekTimes[i][docNum][0] = startTimes.get(position);
            daysOfTheWeekTimes[i][docNum][1] = endTimes.get(position);
            position++;
        }
    }

    private String addTimesToOutputString(ArrayList<String> orderedStartTimes, ArrayList<String> orderedEndTimes) {
        String output = "";
        String time = "00:00";
        DateFormat timeFormat = new SimpleDateFormat("HH:mm");
        if (orderedStartTimes.isEmpty()) {
            output += "00:00 - 23:59\n";
        } else {
            for (int i = 0; i < orderedStartTimes.size(); i++) {
                try {
                    if (timeFormat.parse(orderedStartTimes.get(i)).after(timeFormat.parse(time))) {
                        output += time + " - " + orderedStartTimes.get(i) + "\n";
                        time = orderedEndTimes.get(i);
                    } else if (timeFormat.parse(orderedEndTimes.get(i)).after(timeFormat.parse(time))) {
                        time = orderedStartTimes.get(i);
                    }
                } catch (ParseException e) {
                }
            }
            output += time + " - 23:59\n";
        }
        return output;
    }

    public void getReport(ArrayList<Doctor> doctorsList, String medDisc) {
        String output = "";
        ArrayList<String> docNames, startTimes, endTimes;
        docNames = readTime.getDocNames();
        startTimes = readTime.getStartTimes();
        endTimes = readTime.getEndTimes();
        daysOfTheWeekTimes = new String[7][docNames.size()][2];
        position = 0;
        for (int i = 0; i < docNames.size(); i++) {
            addTimesToDaysOfTheWeek(startTimes, endTimes, i);
        }
        for (int dayNum = 0; dayNum < NUM_DAYS; dayNum++) {
            output += this.sortAndAdd(dayNum, docNames, doctorsList);
        }
        JOptionPane.showMessageDialog(null, output, "Report for " + medDisc, JOptionPane.INFORMATION_MESSAGE);
    }

    private ArrayList orderTimes(String[] toBeOrderedST, String[] toBeOrderedET) {
        ArrayList<String> orderedStartTimes = new ArrayList<>();
        ArrayList<String> orderedEndTimes = new ArrayList<>();
        String[][] sortedArrays = this.sort(toBeOrderedST, toBeOrderedET);
        int arrayIndex = 0;
        for (int i = 0; i < sortedArrays.length; i++) {
            orderedStartTimes.add(sortedArrays[i][0]);
            orderedEndTimes.add(sortedArrays[i][1]);
            if (orderedStartTimes.get(arrayIndex).equals(orderedEndTimes.get(arrayIndex))) {
                orderedStartTimes.remove(arrayIndex);
                orderedEndTimes.remove(arrayIndex);
                arrayIndex--;
            }
            arrayIndex++;
        }
        ArrayList<ArrayList> toBeReturned = new ArrayList<>();
        toBeReturned.add(orderedStartTimes);
        toBeReturned.add(orderedEndTimes);
        return toBeReturned;
    }

    private ArrayList checkAllDoctors(int dayNum, ArrayList<String> docNames, ArrayList<Doctor> relevantDoctors) {
        ArrayList<String> relevantST, relevantET;
        relevantST = new ArrayList<>();
        relevantET = new ArrayList<>();
        for (int i = 0; i < docNames.size(); i++) {
            for (int j = 0; j < relevantDoctors.size(); j++) {
                if (docNames.get(i).equals(relevantDoctors.get(j).getName())) {
                    relevantST.add(daysOfTheWeekTimes[dayNum][i][0]);
                    relevantET.add(daysOfTheWeekTimes[dayNum][i][1]);
                }
            }
        }
        ArrayList<ArrayList> toBeReturned = new ArrayList<>();
        toBeReturned.add(relevantST);
        toBeReturned.add(relevantET);
        return toBeReturned;
    }

    private String[][] sort(String[] startTimesArray, String[] endTimesArray) {
        try {
            DateFormat timeFormat = new SimpleDateFormat("HH:mm");
            int currentPos, size;
            String currentSort, currentSwitch;
            size = startTimesArray.length;
            for (int i = 1; i < size; i++) {
                currentSort = startTimesArray[i];
                currentSwitch = endTimesArray[i];
                currentPos = i;
                while ((currentPos > 0) && (timeFormat.parse(startTimesArray[currentPos - 1]).after(timeFormat.parse(currentSort)))) {
                    startTimesArray[currentPos] = startTimesArray[currentPos - 1];
                    endTimesArray[currentPos] = endTimesArray[currentPos - 1];
                    currentPos--;
                }
                startTimesArray[currentPos] = currentSort;
                endTimesArray[currentPos] = currentSwitch;
            }
        } catch (ParseException e) {
        }
        String[][] toBeReturned = new String[startTimesArray.length][2];
        for (int i = 0; i < startTimesArray.length; i++) {
            toBeReturned[i][0] = startTimesArray[i];
            toBeReturned[i][1] = endTimesArray[i];
        }
        return toBeReturned;
    }

}
