package assignment;

import java.util.ArrayList;

/**
 *
 * @author Jonny
 */
public class ReadTimetable extends ReadAndWrite 
{
    
    private final int NUM_DAYS = 7;
    private ArrayList<String> docNames, startTime, endTime;
    
    public void readFromFile() 
    {
        ArrayList<String> input = read("Availability Update File");
        docNames = new ArrayList<>();
        startTime = new ArrayList<>();
        endTime = new ArrayList<>();
        for (int i = 0; i < input.size(); i++) 
        {
            if (i % (NUM_DAYS+1) == 0) 
            {
                docNames.add(input.get(i));
            } else 
            {
                String inputTemp = input.get(i);
                String[] split = inputTemp.split(" ");
                startTime.add(split[1]);
                endTime.add(split[2]);
            }
        }   
    }
    public ArrayList<String> getDocNames()
    {
        return docNames;
    }
    public ArrayList<String> getStartTimes() 
    {
        return startTime;
    }
    public ArrayList<String> getEndTimes() 
    {
        return endTime;
    }
}
