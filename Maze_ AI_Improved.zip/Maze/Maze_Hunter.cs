﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public class Maze_Hunter
    {
        private enum direction {UP = 1, DOWN = -1, RIGHT = 1, LEFT = -1 }

        private const int hunterWidth = 20;
        private const int hunterHeight = 20;

        private int coordX = 5;
        private int coordY = 5;

        private bool continueUp = false;
        private bool continueDown = false;
        private bool continueLeft = false;
        private bool continueRight = false;

        public bool ContinueU
        {
            get { return continueUp; }
            set { continueUp = value; }
        }
        public bool ContinueD
        {
            get { return continueDown; }
            set { continueDown = value; }
        }
        public bool ContinueL
        {
            get { return continueLeft; }
            set { continueLeft = value; }
        }
        public bool ContinueR
        {
            get { return continueRight; }
            set { continueRight = value; }
        }

        public int CoordX
        {
            get { return coordX; }
            set { coordX = value; }
        }
        public int CoordY
        {
            get { return coordY; }
            set { coordY = value; }
        }

        //get boundary
        internal Rectangle GetBoundingBox()
        {
            return new Rectangle(CoordX, CoordY, hunterWidth, hunterHeight);
        }

        public void Draw(Graphics g)
        {
            //draw the hunter as the yellow rectangle
            g.FillRectangle(new SolidBrush(Color.Red), CoordX * 20 , CoordY * 20, hunterWidth, hunterHeight);
        }  
            
        
        //Move hunter
        public void MoveHunterUp(char cellCheck)
        {
            if (cellCheck != 'w')
            {
                coordY += (int)direction.UP;
                continueUp = true;
            }
            else
            {
                continueUp = false;
            }
        }

        public void MoveHunterDown(char cellCheck)
        {
            if (cellCheck != 'w')
            {
                coordY += (int)direction.DOWN;
                continueDown = true;
            }
            else
            {
                continueDown = false;
            }
        }

        public void MoveHunterRight(char cellCheck)
        {
            if (cellCheck != 'w')
            {
                coordX += (int)direction.RIGHT;
                continueRight = true;
            }
            else
            {
                continueRight = false;
            }
        }

        public void MoveHunterLeft(char cellCheck)
        {
            if (cellCheck != 'w')
            {
                coordX += (int)direction.LEFT;
                continueLeft = true;
            }
            else
            {
                continueLeft = false;
            }
        }
    }
}