﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApp1
{
    public partial class GameForm : Form
    {


        private const int CellSize = 20;

        private MapCell[,] map;

        private Maze_Hunter hunter = new Maze_Hunter();

        private Player player = new Player();

        private Random rand = new Random();


        //Game Timer
        private DateTime startTime = DateTime.MinValue; // time in which the timer starts running 
        private TimeSpan currentTime = TimeSpan.Zero;  //
        private TimeSpan totalTime = TimeSpan.Zero;
        private bool timerRunning = false;

        public GameForm()
        {
            InitializeComponent();
            if (Form1.startTimer == true)
            {
                timer1.Enabled = true;
                timer2.Enabled = true;
            }

            //Game Timer 
            gameTimer.Interval = 1000;
            gameTimer.Tick += new EventHandler(gameTimer_Tick);

            // If the timer isn't already running
            if (!timerRunning)
            {
                // Set the start time to Now
                startTime = DateTime.Now;



                gameTimer.Start();
                timerRunning = true;
            }
            else // If in an event were the timer is already running , the timer will reset
            {
                gameTimer.Stop();
                timerRunning = false;
            }
        }

     

        private MapCell[,] CreateArray(string mapFile)
        {
            int numberRows = 0;
            int numberColumns = 0;

            string line = null;

            try
            {
                StreamReader mapData = new StreamReader(mapFile);

                line = mapData.ReadLine();
                numberColumns = line.Length;

                while (line != null)
                {
                    numberRows++;
                    line = mapData.ReadLine();
                }

                mapData.Close();

            }
            catch (System.IO.IOException e)
            {

                MessageBox.Show(e.Message);
            }

            MapCell[,] map = new MapCell[numberColumns, numberRows];

            try
            {
                StreamReader mapData = new StreamReader(mapFile);

                line = mapData.ReadLine();

                int rowIndex = 0;

                while (line != null)
                {
                    for (int columnIndex = 0; columnIndex < line.Length; columnIndex++)
                    {
                        map[columnIndex, rowIndex] = new MapCell(columnIndex, rowIndex, line[columnIndex]);

                    }

                    rowIndex++;

                    line = mapData.ReadLine();
                }

                mapData.Close();
            }
            catch (System.IO.IOException e)
            {

                MessageBox.Show(e.Message);
            }

            return map;
        }

        private void GameForm_Load(object sender, EventArgs e) // On Load the form will automatically load the map
        {
            map = CreateArray("..\\..\\Resources\\Map\\Level.txt"); // URL Path for the Map

            mazePictureBox.Width = map.GetLength(0) * CellSize;
            mazePictureBox.Height = map.GetLength(1) * CellSize;
        }




        private void mazePictureBox_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;        

            for (int row = 0; row < map.GetLength(0); row++)
                for (int column = 0; column < map.GetLength(1); column++)
                {
                    map[row, column].DrawBackground(g);
                }

            hunter.Draw(g);
            player.Draw(g);
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Down)
            {
                player.CoordY += 10;

                player.CurrentMouthPosition++;

            }
            else if (e.KeyCode == Keys.Up)
            {
                player.CoordY -= 10;
                player.CurrentMouthPosition++;
            }
            else if (e.KeyCode == Keys.Left)
            {
                player.CoordX -= 10;
                player.CurrentMouthPosition++;
            }
            else if (e.KeyCode == Keys.Right)
            {
                player.CoordX += 10;
                player.CurrentMouthPosition++;

            }

            if (player.CoordX < 0) player.CoordX = this.Width;
            else if (player.CoordX > this.Width) player.CoordX = 0;

            if (player.CoordY < 0) player.CoordY = this.Height;
            else if (player.CoordY > this.Height) player.CoordY = 0;

            mazePictureBox.Invalidate();
        }



        private void timer1_Tick(object sender, EventArgs e)
        {
            mazePictureBox.Invalidate();
        }

        private void gameTimer_Tick(object sender, EventArgs e)
        {

            //Ueing TimeSpan.ToString() method will now show the correct HH:MM:SS format
            var timerCount = DateTime.Now - startTime;
            timerCount = new TimeSpan(timerCount.Hours,
                                              timerCount.Minutes,
                                              timerCount.Seconds);

            // The current time is the time since the GameForm opened 
            currentTime = timerCount + totalTime;

            //Display timer 
            GameTimeLBL.Text = currentTime.ToString();

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if(hunter.ContinueU == true)
            {
                hunter.MoveHunterUp(map[hunter.CoordX, hunter.CoordY +1].CellType);
            }
                
            else if(hunter.ContinueD == true)
            {
                hunter.MoveHunterDown(map[hunter.CoordX, hunter.CoordY -1].CellType);
            }
                
            else if(hunter.ContinueL == true)
            {
                hunter.MoveHunterRight(map[hunter.CoordX +1, hunter.CoordY].CellType);
            }
            
            else if(hunter.ContinueR == true)
            {
                hunter.MoveHunterLeft(map[hunter.CoordX -1, hunter.CoordY].CellType);
            }
            else
            {            
                switch (rand.Next(4))
                {
                    case 0:
                        hunter.MoveHunterUp(map[hunter.CoordX, hunter.CoordY +1].CellType);                 
                        break;

                    case 1:
                        hunter.MoveHunterDown(map[hunter.CoordX, hunter.CoordY -1].CellType);                 
                        break;

                    case 2:
                        hunter.MoveHunterRight(map[hunter.CoordX +1, hunter.CoordY].CellType);                   
                        break;

                    case 3:
                        hunter.MoveHunterLeft(map[hunter.CoordX -1, hunter.CoordY].CellType);                   
                        break;                    
                }
            }
        }
    }
}
