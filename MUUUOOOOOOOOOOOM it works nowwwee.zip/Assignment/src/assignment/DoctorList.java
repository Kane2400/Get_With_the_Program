package assignment;

/**
 *
 * @author B00718269
 */
import java.io.*;
import java.util.*;

public class DoctorList 
{

    private ArrayList<Doctor> docList = new ArrayList<>();
    private Scanner readin;
    private File doctorInput = new File("doctorInput.txt");
    private ReadAndWriteDoctor readWriteDoctor = new ReadAndWriteDoctor();    

    public DoctorList() 
    {
    }

    public void addDoctor(String name, String address, String prefContact, String conID, String medDisc, String lastCert) 
    {
        if (lastCert.equals("")) 
        {
            lastCert = "N/A";
        }
        Doctor newDoc = new Doctor(name, address, prefContact, conID, medDisc, lastCert);
        docList.add(newDoc);
        readWriteDoctor.writeDoctor(docList);
    }

    public void removeDoctor(int index) 
    {
        docList.remove(index);
        readWriteDoctor.writeDoctor(docList);
    }

    public ArrayList<Doctor> getDoctorList() 
    {
        ArrayList<Doctor> arrayList = new ArrayList<>();
        arrayList = readWriteDoctor.readDoctor(arrayList);
        docList = arrayList;
        return arrayList;
    }
}
