package assignment;

import java.text.*;
import java.util.*;
import javax.swing.JOptionPane;

/**
 *
 * @author Jonny
 */
public class Availability 
{

    private static String[] doctors;
    private final String[] daysOfTheWeek = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
    private final int NUM_DAYS = 7;
    private String[][] daysRelevant;
    private int numDoctors;
    ReadTimetable readTime = new ReadTimetable();
    
    String[][] sunday, monday, tuesday, wednesday, thursday, friday, saturday;

    public Availability() 
    {
        readTime.readFromFile();
        int dayNum = 0;
        ArrayList<String> dn = readTime.getDocNames();
        doctors = new String[dn.size()];
        for (int k = 0; k < doctors.length; k++) {
            doctors[k] = dn.get(k);
        }
        ArrayList<String> st = readTime.getStartTimes();
        ArrayList<String> et = readTime.getEndTimes();
        for (int i = 0; i < daysOfTheWeek.length; i++) 
        {
            if (getDay().equals(daysOfTheWeek[i])) 
            {
                dayNum = i;
                break;
            }
        }
        daysRelevant = new String[st.size()][2];
        int position = dayNum;
        for (int j = 0; j < dn.size(); j++) {
            daysRelevant[j][0] = st.get(position);
            daysRelevant[j][1] = et.get(position);
            position += NUM_DAYS;
        }
        numDoctors = dn.size();
    }

    private String parseTime(int docNum) 
    {
        Date date = new Date();
        DateFormat timeFormat = new SimpleDateFormat("HH:mm");
        try 
        {
            if (timeFormat.parse(getTime()).after(timeFormat.parse(daysRelevant[docNum][0]))
                    && timeFormat.parse(timeFormat.format(date)).before(timeFormat.parse(daysRelevant[docNum][1]))) 
            {
                return "yes";
            }
        } catch (ParseException e) {
            System.out.println("Error when Parsing");
        }
        return "no";
    }

    public String getAvailability(String docname) 
    {
        int docNum = getDocNum(docname);
        if (docNum < numDoctors && docNum >= 0) 
        {
            return this.parseTime(docNum);
        }
        return "Error";
    }

    private int getDocNum(String docname) 
    {
        for (int docNum = 0; docNum < numDoctors; docNum++) 
        {
            if (doctors[docNum].equals(docname)) 
            {
                return docNum;
            }
        }
        return numDoctors;
    }

    private String getTime() 
    { // returns the current time to be compared to those stored in the availability update file
        DateFormat timeFormat = new SimpleDateFormat("HH:mm");
        Date time = new Date();
        return timeFormat.format(time);
    }

    private String getDay() { // returns the current day
        DateFormat dayFormat = new SimpleDateFormat("EEEE");
        Date day = new Date();
        return dayFormat.format(day);
    }
    
    private void declareDaysOfTheWeek(ArrayList<String> docNames)
    {
        sunday = new String[docNames.size()][2];
        monday = new String[docNames.size()][2];
        tuesday = new String[docNames.size()][2];
        wednesday = new String[docNames.size()][2];
        thursday = new String[docNames.size()][2];
        friday = new String[docNames.size()][2];
        saturday = new String[docNames.size()][2];
    }
    
    private void initialiseDaysOfTheWeek(ArrayList<String> doctorsList, ArrayList<String> startTimes, ArrayList<String> endTimes)
    {     
        int index = 0;
        for (int i = 0; i < doctorsList.size(); i++) 
        {
            sunday[i][0] = startTimes.get(index);
            sunday[i][1] = endTimes.get(index);    
            index++; 
            monday[i][0] = startTimes.get(index);
            monday[i][1] = endTimes.get(index);     
            index++; 
            tuesday[i][0] = startTimes.get(index);
            tuesday[i][1] = endTimes.get(index);   
            index++; 
            wednesday[i][0] = startTimes.get(index);
            wednesday[i][1] = endTimes.get(index);  
            index++; 
            thursday[i][0] = startTimes.get(index);
            thursday[i][1] = endTimes.get(index);   
            index++; 
            friday[i][0] = startTimes.get(index);
            friday[i][1] = endTimes.get(index);     
            index++; 
            saturday[i][0] = startTimes.get(index);
            saturday[i][1] = endTimes.get(index);   
            index++; 
        }
    }
    
    private void relevantStartAndEndTimes(ArrayList<String> relevantST, ArrayList<String> relevantET, int dayNum, int i)
    {
        switch (dayNum) 
        {
            case 0:
                relevantST.add(sunday[i][0]);
                relevantET.add(sunday[i][1]);
                break;
            case 1:
                relevantST.add(monday[i][0]);
                relevantET.add(monday[i][1]);
                break;
            case 2:
                relevantST.add(tuesday[i][0]);
                relevantET.add(tuesday[i][1]);
                break;
            case 3:
                relevantST.add(wednesday[i][0]);
                relevantET.add(wednesday[i][1]);
                break;
            case 4:
                relevantST.add(thursday[i][0]);
                relevantET.add(thursday[i][1]);
                break;
            case 5:
                relevantST.add(friday[i][0]);
                relevantET.add(friday[i][1]);
                break;
            case 6:
                relevantST.add(saturday[i][0]);
                relevantET.add(saturday[i][1]);
                break;
            default:
                break;
        }
    }
        
    private void checkAllDoctors(ArrayList<String> relevantST, ArrayList<String> relevantET, ArrayList<String> docNamesArrayList, ArrayList<Doctor> doctorsList, int dayNum)
    {
        for (int i = 0; i < docNamesArrayList.size(); i++) 
            {
                for (int j = 0; j < doctorsList.size(); j++) 
                {
                    if (docNamesArrayList.get(i).equals(doctorsList.get(j).getName())) 
                    {
                        this.relevantStartAndEndTimes(relevantST, relevantET,dayNum, i);
                    }
                }
            }
    }

    private void removeTimesWhereAvailable(String[][] sortedArrays, ArrayList<String> orderedStartTimes, ArrayList<String> orderedEndTimes)
    {
        int arrayIndex = 0;
        for (int i = 0; i < sortedArrays.length; i++) 
        {
            orderedStartTimes.add(sortedArrays[i][0]);
            orderedEndTimes.add(sortedArrays[i][1]);
            if (orderedStartTimes.get(arrayIndex).equals(orderedEndTimes.get(arrayIndex))) 
            {
                orderedStartTimes.remove(arrayIndex);
                orderedEndTimes.remove(arrayIndex);
                arrayIndex--;
            }
                arrayIndex++;
        }
    }
    
    private void outputReport(ArrayList<String> orderedSTArray, ArrayList<String> orderedETArray, int dayNum, String medDisc)
    {
        String output = "";
        output += daysOfTheWeek[dayNum] + "\n";
        String time = "00:00";
        DateFormat timeFormat = new SimpleDateFormat("HH:mm");
        if (orderedSTArray.size() == 0) 
        {
            output += "00:00 - 23:59\n";
        } else 
        {
            for (int i = 0; i < orderedSTArray.size(); i++) 
            {
                try 
                {
                    if (timeFormat.parse(orderedSTArray.get(i)).after(timeFormat.parse(time))) 
                    {
                        output += time + " - " + orderedSTArray.get(i) + "\n";
                        time = orderedETArray.get(i);
                    } else if (timeFormat.parse(orderedETArray.get(i)).after(timeFormat.parse(time))) 
                    {
                        time = orderedSTArray.get(i);
                    }
                } catch (ParseException e) 
                {
                    System.out.println("Error when Parsing");
                }
            }
                output += time + " - 23:59\n";
        }
        output += "\n";
        JOptionPane.showMessageDialog(null, output, "Report for " + medDisc + " discipline", JOptionPane.INFORMATION_MESSAGE);
    }
    
    public void getReport(ArrayList<Doctor> doctorsList, String medDisc) 
    {
        ArrayList<String> docNames, startTimes, endTimes;
        ArrayList<String> orderedSTArray  = new ArrayList<>(); 
        ArrayList<String> orderedETArray = new ArrayList<>();    
        ArrayList<String> relevantST, relevantET;
        docNames = readTime.getDocNames();
        startTimes = readTime.getStartTimes();
        endTimes = readTime.getEndTimes();
        this.declareDaysOfTheWeek(docNames);
        this.initialiseDaysOfTheWeek(docNames, startTimes, endTimes);
        for (int dayNum = 0; dayNum < NUM_DAYS; dayNum++) 
        {
            relevantST = new ArrayList<>();
            relevantET = new ArrayList<>();
            this.checkAllDoctors(relevantST, relevantET, docNames, doctorsList, dayNum);          
           
            String[] orderedSTArrayList, orderedETArrayList;
            orderedSTArrayList = new String[relevantST.size()];
            orderedETArrayList = new String[relevantET.size()];
            for (int i = 0; i < relevantST.size(); i++) 
            {
                orderedSTArrayList[i] = relevantST.get(i);
                orderedETArrayList[i] = relevantET.get(i);
            }
            String[][] sortedArrays = this.sort(orderedSTArrayList, orderedETArrayList);
            this.removeTimesWhereAvailable(sortedArrays, orderedSTArray, orderedETArray);
            this.outputReport(orderedSTArray, orderedETArray, dayNum, medDisc);                            
        }              
    }

    private String[][] sort(String[] toBeSorted, String[] switchAlongWith) 
    {
        try 
        {
            DateFormat timeFormat = new SimpleDateFormat("HH:mm");
            int i, index, size;
            String currentSort, currentSwitch;
            size = toBeSorted.length;
            for (i = 1; i < size; i++) {
                currentSort = toBeSorted[i];
                currentSwitch = switchAlongWith[i];
                index = i;
                while ((index > 0) && (timeFormat.parse(toBeSorted[index - 1]).after(timeFormat.parse(currentSort)))) 
                {
                    toBeSorted[index] = toBeSorted[index - 1];
                    switchAlongWith[index] = switchAlongWith[index - 1];
                    index--;
                }
                toBeSorted[index] = currentSort;
                switchAlongWith[index] = currentSwitch;
            }
        } catch (ParseException e) 
        {
            System.out.println("Error when parsing");
        }
        String[][] toBeReturned = new String[toBeSorted.length][2];
        for (int i = 0; i < toBeSorted.length; i++) {
            toBeReturned[i][0] = toBeSorted[i];
            toBeReturned[i][1] = switchAlongWith[i];
        }
        return toBeReturned;
    }
}
