package assignment;


import java.util.ArrayList;


/**
 *
 * @author Jonny
 */
public class ReadAndWriteDiscipline extends ReadAndWrite 
{

    private ArrayList<String> input;
    private final String FILENAME = "Medical Disciplines File";
    public static int doctorFileLength;

    public ArrayList readDiscipline(ArrayList<Discipline> disList)
    {
        ArrayList<Discipline> disciplineArray = disList;
        input = read(FILENAME);
        for (int i = 0; i < input.size(); i++) 
        {
            String[] split = input.get(i).split("\t");
            
            Discipline tempDis = new Discipline(split[0], split[1]);
            disciplineArray.add(tempDis);
        }
        return disciplineArray;
    }

    public void writeDiscipline(ArrayList<Discipline> disciplineList) 
    {
        ArrayList<String> disciplineListString = new ArrayList<>();
        for (int i = 0; i < disciplineList.size(); i++) 
        {
            disciplineListString.add(disciplineList.get(i).getName() + "\t" + disciplineList.get(i).getDescription());
        }
        this.write(FILENAME, disciplineListString);
    }

}

