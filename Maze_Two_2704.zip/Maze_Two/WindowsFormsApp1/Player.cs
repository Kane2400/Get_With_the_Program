﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    class Player
    {
        private Image[] pacmanImage = new Image[4];
        private int currentMouthPosition = 0;

        //Need to figure out importing images
        //pacmanImage[0] = Image.FromFile("..\\..\\images\\pac32_left_close.png");
        //pacmanImage[1] = Image.FromFile("..\\..\\images\\pac32_left_open.png");
        //pacmanImage[2] = Image.FromFile("..\\..\\images\\pac32_left_wide.png");
        //pacmanImage[3] = Image.FromFile("..\\..\\images\\pac32_left_widest.png");

        enum direction { UP = 1, DOWN = -1, LEFT = -1, RIGHT = 1 }

        private int playerWidth = 20;
        private int playerHeight = 20;

        private int coordX = 47;
        private int coordY = 13;

        public int CurrentMouthPosition
        {
            get { return currentMouthPosition; }
            set { currentMouthPosition = value; }
        }


        public int CoordX
        {
            get { return coordX; }
            set { coordX = value; }
        }

        public int CoordY
        {
            get { return coordY; }
            set { coordY = value; }
        }

        public int PlayerWidth
        {
            get { return playerWidth; }
            set { playerWidth = value; }
        }

        public int PlayerHeight
        {
            get { return playerHeight; }
            set { playerHeight = value; }
        }

        internal Rectangle GetBoundingBox()
        {
            return new Rectangle(CoordX, CoordY, playerWidth, playerHeight);
        }

        public void Draw(Graphics g)
        {
            g.FillRectangle(new SolidBrush(Color.Yellow), CoordX * 20, CoordY * 20, playerWidth, playerHeight);
        }


        ////Move player
        //public void MovePlayerUp()
        //{
        //    coordY += (int)direction.UP;
        //}

        //public void MovePlayerDown()
        //{
        //    coordY += (int)direction.DOWN;
        //}

        //public void MovePlayerRight()
        //{
        //    coordX += (int)direction.RIGHT;
        //}

        //public void MovePlayerLeft()
        //{
        //    coordX += (int)direction.LEFT;
        //}


        //Move hunter
        public void MovePlayerUp(char cellCheck)
        {
            if (cellCheck != 'w')
            {
                coordY += (int)direction.UP;
            }
        }

        public void MovePlayerDown(char cellCheck)
        {
            if (cellCheck != 'w')
            {
                coordY += (int)direction.DOWN;
            }
        }

        public void MovePlayerRight(char cellCheck)
        {
            if (cellCheck != 'w')
            {
                coordX += (int)direction.RIGHT;
            }
        }

        public void MovePlayerLeft(char cellCheck)
        {
            if (cellCheck != 'w')
            {
                coordX += (int)direction.LEFT;
            }
        }

    }
}
