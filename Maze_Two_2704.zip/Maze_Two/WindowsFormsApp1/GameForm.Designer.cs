﻿namespace WindowsFormsApp1
{
    partial class GameForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.mazePictureBox = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.gameToolBar = new System.Windows.Forms.ToolStrip();
            this.helpLbl = new System.Windows.Forms.ToolStripLabel();
            this.aboutLbl = new System.Windows.Forms.ToolStripLabel();
            this.gameTimer = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.LblTimer = new System.Windows.Forms.Label();
            this.GameTimeLBL = new System.Windows.Forms.Label();
            this.GamePanel = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.lblTextLives = new System.Windows.Forms.Label();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            ((System.ComponentModel.ISupportInitialize)(this.mazePictureBox)).BeginInit();
            this.gameToolBar.SuspendLayout();
            this.GamePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            this.SuspendLayout();
            // 
            // mazePictureBox
            // 
            this.mazePictureBox.BackColor = System.Drawing.Color.Black;
            this.mazePictureBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.mazePictureBox.Location = new System.Drawing.Point(6, 86);
            this.mazePictureBox.Name = "mazePictureBox";
            this.mazePictureBox.Size = new System.Drawing.Size(840, 364);
            this.mazePictureBox.TabIndex = 0;
            this.mazePictureBox.TabStop = false;
            this.mazePictureBox.Paint += new System.Windows.Forms.PaintEventHandler(this.mazePictureBox_Paint);
            // 
            // timer1
            // 
            this.timer1.Interval = 17;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Interval = 500;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // gameToolBar
            // 
            this.gameToolBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.helpLbl,
            this.aboutLbl});
            this.gameToolBar.Location = new System.Drawing.Point(0, 0);
            this.gameToolBar.Name = "gameToolBar";
            this.gameToolBar.Size = new System.Drawing.Size(843, 25);
            this.gameToolBar.TabIndex = 1;
            this.gameToolBar.Text = "toolStrip1";
            // 
            // helpLbl
            // 
            this.helpLbl.Name = "helpLbl";
            this.helpLbl.Size = new System.Drawing.Size(32, 22);
            this.helpLbl.Text = "Help";
            this.helpLbl.Click += new System.EventHandler(this.helpLbl_Click);
            // 
            // aboutLbl
            // 
            this.aboutLbl.Name = "aboutLbl";
            this.aboutLbl.Size = new System.Drawing.Size(40, 22);
            this.aboutLbl.Text = "About";
            this.aboutLbl.Click += new System.EventHandler(this.aboutLbl_Click);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(15, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Timer:";
            // 
            // LblTimer
            // 
            this.LblTimer.AutoSize = true;
            this.LblTimer.Location = new System.Drawing.Point(68, 37);
            this.LblTimer.Name = "LblTimer";
            this.LblTimer.Size = new System.Drawing.Size(0, 13);
            this.LblTimer.TabIndex = 2;
            // 
            // GameTimeLBL
            // 
            this.GameTimeLBL.AutoSize = true;
            this.GameTimeLBL.BackColor = System.Drawing.SystemColors.Control;
            this.GameTimeLBL.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.GameTimeLBL.Location = new System.Drawing.Point(56, 11);
            this.GameTimeLBL.Name = "GameTimeLBL";
            this.GameTimeLBL.Size = new System.Drawing.Size(2, 15);
            this.GameTimeLBL.TabIndex = 3;
            // 
            // GamePanel
            // 
            this.GamePanel.BackColor = System.Drawing.SystemColors.Control;
            this.GamePanel.Controls.Add(this.trackBar1);
            this.GamePanel.Controls.Add(this.label2);
            this.GamePanel.Controls.Add(this.lblTextLives);
            this.GamePanel.Controls.Add(this.GameTimeLBL);
            this.GamePanel.Controls.Add(this.label1);
            this.GamePanel.Location = new System.Drawing.Point(3, 28);
            this.GamePanel.Name = "GamePanel";
            this.GamePanel.Size = new System.Drawing.Size(843, 42);
            this.GamePanel.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Location = new System.Drawing.Point(336, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(2, 15);
            this.label2.TabIndex = 5;
            // 
            // lblTextLives
            // 
            this.lblTextLives.AutoSize = true;
            this.lblTextLives.Location = new System.Drawing.Point(242, 11);
            this.lblTextLives.Name = "lblTextLives";
            this.lblTextLives.Size = new System.Drawing.Size(88, 13);
            this.lblTextLives.TabIndex = 4;
            this.lblTextLives.Text = "Remaining Lives:";
            // 
            // trackBar1
            // 
            this.trackBar1.AutoSize = false;
            this.trackBar1.Location = new System.Drawing.Point(451, -3);
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(104, 45);
            this.trackBar1.TabIndex = 6;
            this.trackBar1.TabStop = false;
            // 
            // GameForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(843, 443);
            this.Controls.Add(this.GamePanel);
            this.Controls.Add(this.LblTimer);
            this.Controls.Add(this.gameToolBar);
            this.Controls.Add(this.mazePictureBox);
            this.Name = "GameForm";
            this.Text = "Maze Game";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.GameForm_FormClosing);
            this.Load += new System.EventHandler(this.GameForm_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.mazePictureBox)).EndInit();
            this.gameToolBar.ResumeLayout(false);
            this.gameToolBar.PerformLayout();
            this.GamePanel.ResumeLayout(false);
            this.GamePanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox mazePictureBox;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.ToolStrip gameToolBar;
        private System.Windows.Forms.ToolStripLabel helpLbl;
        private System.Windows.Forms.ToolStripLabel aboutLbl;
        private System.Windows.Forms.Timer gameTimer;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label LblTimer;
        private System.Windows.Forms.Label GameTimeLBL;
        private System.Windows.Forms.Panel GamePanel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblTextLives;
        private System.Windows.Forms.TrackBar trackBar1;
    }
}

