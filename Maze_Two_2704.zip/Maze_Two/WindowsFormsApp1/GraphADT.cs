﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace WindowsFormsApp1
{
    interface GraphADT
    {
        // Adds edge from N1 to N2
        void SetEdge(Node start, Node end, int weight);
        // Removes an edge
        void DeleteEdge(Node start, Node end);
        // 1 if there is an edge in graph from N1 to N2, else 0 
        bool IsEdgeExists(Node start, Node end);
        //return the size of the graph
        int GetSize();

        //display the graph
        void DumpGraph();
    }
}