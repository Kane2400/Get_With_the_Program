﻿using System.Collections;
using System.Drawing;

namespace WindowsFormsApp1
{

    
    public class MapCell
    {
        const int SizeOfCell = 20; //cell dimension in pixels
        private int x, y;
        private char type;
        private bool isVisible = true;
        private UndirectedGraph mazeGraph;
        private Node[,] mazeNode;
        private Guard hunter;


        //Constructor
        public MapCell(int x, int y, char type)
        {
            this.type = type;
            this.x = x;
            this.y = y;
            //this.SetupGraph();
        }

        //Set cell as visited (no pill inside it)
        public bool IsVisible
        {
            get
            {
                return isVisible;
            }

            set
            {
                isVisible = value;
            }
        }

        public char CellType
        {
            get { return type; }
            set { type = value; }
        }


        //draw the cell 
        public virtual void DrawBackground(Graphics g)
        {

            switch (type)
            {
                case 'w'://wall
                    g.FillRectangle(Brushes.Black, x * SizeOfCell, y * SizeOfCell, SizeOfCell, SizeOfCell);
                    break;
                case 'p'://path
                    g.FillRectangle(Brushes.White, x * SizeOfCell, y * SizeOfCell, SizeOfCell, SizeOfCell);
                    break;
                case 's'://starting position
                    g.FillRectangle(Brushes.Blue, x * SizeOfCell, y * SizeOfCell, SizeOfCell, SizeOfCell);
                    g.DrawString("S", new Font("Arial", 12, FontStyle.Bold), new SolidBrush(Color.Red), new Point(x * SizeOfCell, y * SizeOfCell));
                    break;
                case 'f'://finishing line
                    g.FillRectangle(Brushes.Blue, x * SizeOfCell, y * SizeOfCell, SizeOfCell, SizeOfCell);
                    g.DrawString("F", new Font("Arial", 12, FontStyle.Bold), new SolidBrush(Color.Red), new Point(x * SizeOfCell, y * SizeOfCell));
                    break;
                case 'g'://guard position
                    g.FillRectangle(Brushes.Blue, x * SizeOfCell, y * SizeOfCell, SizeOfCell, SizeOfCell);
                    g.DrawString("G", new Font("Arial", 12, FontStyle.Bold), new SolidBrush(Color.Red), new Point(x * SizeOfCell, y * SizeOfCell));
                    break;
                default:
                    break;
            }
        }

        public void SetupGraph()
        {
            mazeGraph = new UndirectedGraph(49 * 30);
            mazeNode = new Node[49, 30];

            //for every cell create a node and add it to yardGraph
            for (int row = 0; row < 49; row++)
            {
                for (int column = 0; column < 30; column++)
                {
                    mazeNode[row, column] = new Node(row, column);
                    mazeGraph.AddNode(mazeNode[row, column]);
                }
            }

            //set an edge


            for (int row = 0; row < 49 - 1; row++)
            {
                for (int column = 0; column < 30 - 1; column++)
                {
                    mazeGraph.SetEdge(mazeNode[row, column], mazeNode[row, column + 1], 1);
                    mazeGraph.SetEdge(mazeNode[row, column], mazeNode[row + 1, column], 1);
                }
            }

            //last row
            for (int column = 0; column < 30 - 1; column++)
            {
                int row = 49 - 1;
                mazeGraph.SetEdge(mazeNode[row, column], mazeNode[row, column + 1], 1);
                // yardGraph.SetEdge(yardNode[row, column], yardNode[row + 1, column], 1);
            }

            //last column
            for (int row = 0; row < 49 - 1; row++)
            {
                int column = 30 - 1;
                // yardGraph.SetEdge(yardNode[row, column], yardNode[row, column + 1], 1);
                mazeGraph.SetEdge(mazeNode[row, column], mazeNode[row + 1, column], 1);
            }




            //  yardGraph.DumpGraph();
        }

        public void FindShortestPath(int srcRow, int srcColumn, int dstRow, int dstColumn)
        {
            ArrayList path = mazeGraph.GetShortestPath(mazeNode[srcRow, srcColumn], mazeNode[dstRow, dstColumn]);

            // Console.WriteLine("Number of nodes in the path:" + path.Count);

            if (path.Count == 1)
            {
                hunter.CoordX = (path[0] as Node).Column;
                hunter.CoordY = (path[0] as Node).Row;
            }
            else
            {
                hunter.CoordX = (path[path.Count - 2] as Node).Column;
                hunter.CoordY = (path[path.Count - 2] as Node).Row;
            }
        }
    }
  }

