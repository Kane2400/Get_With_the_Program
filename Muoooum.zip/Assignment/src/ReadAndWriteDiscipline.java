
import java.util.ArrayList;


/**
 *
 * @author Jonny
 */
public class ReadAndWriteDiscipline extends ReadAndWrite 
{

    private ArrayList<String> input;
    private String filename = "Medical Disciplines File";
    //private String[] headings = {"Name", "Address", "Preferred Contact Means", "Contact ID", "Specialism", "Certification Date"};
    public static int doctorFileLength;

    public ArrayList readDiscipline(ArrayList<Discipline> disList)
    {
        ArrayList<Discipline> disciplineArray = disList;
        input = read(filename);
        for (int i = 0; i < input.size(); i++) 
        {
            String[] split = input.get(i).split("\t");
            
            Discipline tempDis = new Discipline(split[0], split[1]);
            disciplineArray.add(tempDis);
        }
        return disciplineArray;
    }

    public void writeDoctor(ArrayList<Discipline> disciplineList) 
    {
        ArrayList<String> disciplineListString = new ArrayList<>();
        String output = "";
        /*doctorListString.add(headings[0]
                + "\t" + headings[1]
                + "\t" + headings[2] 
                + "\t" + headings[3] 
                + "\t" + headings[4]
                + "\t" + headings[5]);*/
        for (int i = 0; i < disciplineList.size(); i++) 
        {
            disciplineListString.add(disciplineList.get(i).getName() + "\t" + disciplineList.get(i).getDescription());
        }
        write(filename, disciplineListString);
    }

    /*public String[][] getDoctors() 
    {
        return doctorArray;
    }*/
}

