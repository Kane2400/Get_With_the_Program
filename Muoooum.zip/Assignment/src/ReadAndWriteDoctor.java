import java.util.ArrayList;

/**
 *
 * @author Jonny
 */
public class ReadAndWriteDoctor extends ReadAndWrite 
{

    private ArrayList<String> input;
    private String filename = "Doctor Records File";
    private String[] headings = {"Name", "Address", "Preferred Contact Means", "Contact ID", "Specialism", "Certification Date"};
    public static int doctorFileLength;

    public ArrayList readDoctor(ArrayList<Doctor> docList)
    {
        ArrayList<Doctor> doctorArray = docList;
        input = read(filename);
        input.remove(0);
        for (int i = 0; i < input.size(); i++) 
        {
            String[] split = input.get(i).split("\t");
            
            Doctor tempDoc = new Doctor(split[0], split[1], split[2], split[3], split[4], split[5]);
            doctorArray.add(tempDoc);
        }
        return doctorArray;
    }

    public void writeDoctor(ArrayList<Doctor> doctorList) 
    {
        ArrayList<String> doctorListString = new ArrayList<>();
        String output = "";
        doctorListString.add(headings[0]
                + "\t" + headings[1]
                + "\t" + headings[2] 
                + "\t" + headings[3] 
                + "\t" + headings[4]
                + "\t" + headings[5]);
        for (int i = 0; i < doctorList.size(); i++) 
        {
            doctorListString.add(doctorList.get(i).getAll());
        }
        write("Doctor Records File", doctorListString);
    }

    /*public String[][] getDoctors() 
    {
        return doctorArray;
    }*/
}
