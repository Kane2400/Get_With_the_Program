package assignment;

import java.util.ArrayList;

/**
 *
 * @author B00718269, B00718694, B00710574, B00716828
 */
public class ReadAndWriteDoctor extends ReadAndWrite 
{

    private ArrayList<String> input;
    private final String FILENAME = "Doctor Records File";
    private final String[] HEADINGS = {"Name", "Address", "Preferred Contact Means", "Contact ID", "Specialism", "Certification Date"};

    //Reads lines from file and splits into fields for each doctor
    public ArrayList readDoctor(ArrayList<Doctor> docList)
    {
        ArrayList<Doctor> doctorArray = docList;
        input = read(FILENAME);
        input.remove(0);
        for (int i = 0; i < input.size(); i++) 
        {
            String[] split = input.get(i).split("\t");
            
            Doctor tempDoc = new Doctor(split[0], split[1], split[2], split[3], split[4], split[5]);
            doctorArray.add(tempDoc);
        }
        return doctorArray;
    }

    //Concatenates the doctor details and writes to file
    public void writeDoctor(ArrayList<Doctor> doctorList) 
    {
        ArrayList<String> doctorListString = new ArrayList<>();
        doctorListString.add(HEADINGS[0]
                + "\t" + HEADINGS[1]
                + "\t" + HEADINGS[2] 
                + "\t" + HEADINGS[3] 
                + "\t" + HEADINGS[4]
                + "\t" + HEADINGS[5]);
        for (int i = 0; i < doctorList.size(); i++) 
        {
            doctorListString.add(doctorList.get(i).getAll());
        }
        this.write("Doctor Records File", doctorListString);
    }
}