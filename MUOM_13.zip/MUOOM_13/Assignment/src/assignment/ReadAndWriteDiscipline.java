package assignment;


import java.util.ArrayList;


/**
 *
 * @author B00718269, B00718694, B00710574, B00716828
 */
public class ReadAndWriteDiscipline extends ReadAndWrite 
{

    private ArrayList<String> input;
    private final String FILENAME = "Medical Disciplines File";
    
    //Reads lines from file and splits into fields for each discipline
    public ArrayList readDiscipline(ArrayList<Discipline> disList)
    {
        ArrayList<Discipline> disciplineArray = disList;
        input = read(FILENAME);
        for (int i = 0; i < input.size(); i++) 
        {
            String[] split = input.get(i).split("\t");
            
            Discipline tempDis = new Discipline(split[0], split[1]);
            disciplineArray.add(tempDis);
        }
        return disciplineArray;
    }

    //Concatenates the discipline details and writes to file
    public void writeDiscipline(ArrayList<Discipline> disciplineList) 
    {
        ArrayList<String> disciplineListString = new ArrayList<>();
        for (int i = 0; i < disciplineList.size(); i++) 
        {
            disciplineListString.add(disciplineList.get(i).getName() + "\t" + disciplineList.get(i).getDescription());
        }
        this.write(FILENAME, disciplineListString);
    }
}