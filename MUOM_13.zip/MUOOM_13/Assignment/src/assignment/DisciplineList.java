package assignment;

/**
 *
 * @author B00718269, B00718694, B00710574, B00716828
 */
import java.util.*;

public class DisciplineList 
{

    private ArrayList<Discipline> disArrayList = new ArrayList<>(); 
    private ReadAndWriteDiscipline readWriteDiscipline =  new ReadAndWriteDiscipline();
   
    public DisciplineList() 
    {
    }
    
    //Creates new discipline and adds details to ArrayList and file
    public void addDiscipline(String name, String desc) 
    {
        Discipline newDis = new Discipline(name, desc);
        disArrayList.add(newDis);
        readWriteDiscipline.writeDiscipline(disArrayList);
    }
    
    //Edits details of existing discipline from ArrayList and writes changes to file
    public void editDiscipline(String name, String desc, int index)
    {
        Discipline newDis = new Discipline(name, desc);
        disArrayList.remove(index);
        disArrayList.add(index, newDis);
        readWriteDiscipline.writeDiscipline(disArrayList);
    }

    //Removes existing discipline from ArrayList and file
    public void removeDiscipline(int index) 
    {
        disArrayList.remove(index);
        readWriteDiscipline.writeDiscipline(disArrayList);
    }

    //Getter method
    public ArrayList<Discipline> getDisciplineList() 
    {
        ArrayList<Discipline> arrayList = new ArrayList<>();
        arrayList = readWriteDiscipline.readDiscipline(arrayList);
        disArrayList = arrayList;
        return arrayList;
    }
}
