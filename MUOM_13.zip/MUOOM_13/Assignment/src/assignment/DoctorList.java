package assignment;

/**
 *
 * @author B00718269, B00718694, B00710574, B00716828
 */
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class DoctorList 
{

    private ArrayList<Doctor> docList = new ArrayList<>();
    private ReadAndWriteDoctor readWriteDoctor = new ReadAndWriteDoctor();    

    public DoctorList() 
    {
    }

    //Creates new doctor and adds details to ArrayList and file
    public void addDoctor(String name, String address, String prefContact, String conID, String medDisc, String lastCert) 
    {
        lastCert = validateCertDate(medDisc, lastCert);
        Doctor newDoc = new Doctor(name, address, prefContact, conID, medDisc, lastCert);
        docList.add(newDoc);
        readWriteDoctor.writeDoctor(docList);
    }
    
    //Edits details of existing doctor from ArrayList and writes changes to file
    public void editDoctor(String name, String address, String prefContact, String conID, String medDisc, String lastCert, int index)
    {
        lastCert = validateCertDate(medDisc, lastCert);
        Doctor newDoc = new Doctor(name, address, prefContact, conID, medDisc, lastCert);
        docList.remove(index);
        docList.add(index, newDoc);
        readWriteDoctor.writeDoctor(docList);
    }

    //Removes existing doctor from ArrayList and file
    public void removeDoctor(int index) 
    {
        docList.remove(index);
        readWriteDoctor.writeDoctor(docList);
    }

    //Getter method
    public ArrayList<Doctor> getDoctorList() 
    {
        ArrayList<Doctor> arrayList = new ArrayList<>();
        arrayList = readWriteDoctor.readDoctor(arrayList);
        docList = arrayList;
        return arrayList;
    }
    
    //Checks whether the surgeon has been certified in the past year
    private String validateCertDate(String medDisc, String lastCert) 
    {
        if (!medDisc.equals("Surgery")) 
        {
            lastCert = "N/A";
        }
        else 
        {
            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            Date currentDate = new Date();
            String dateString = dateFormat.format(currentDate);
            try 
            {
                Date certDate = dateFormat.parse(lastCert);
                System.out.println(dateFormat.format(certDate));
            } 
            catch (ParseException e) 
            {
                lastCert = dateString;
            }
        }
        return lastCert;
    }
}
