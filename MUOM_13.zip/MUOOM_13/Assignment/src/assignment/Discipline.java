package assignment;

/**
 *
 * @author B00718269, B00718694, B00710574, B00716828
 */
public class Discipline 
{
    //Details of the discipline
    private String disName;
    private String description;

    //Constructor for discipline to initialise new disciplines
    public Discipline(String name, String desc) 
    {
        this.disName = name;
        this.description = desc;
    }

    //Setters and getters
    
    public String getName() 
    {
        return this.disName;
    }

    public void setName(String name) 
    {
        this.disName = name;
    }

    public String getDescription() 
    {
        return this.description;
    }

    public void setDescription(String desc) 
    {
        this.description = desc;
    }
}
