﻿using System;

public class MazeHunter
{
	public Class1()
	{

        private int cheeseWidth = 20;
        private int cheeseHeight = 10;

        private int cheeseX = 0;
        private int cheeseY = 0;

        private Form1 parent;
        private Random rand = new Random();

        public Maze_Hunter(Form1 parent)
        {
            this.parent = parent;
            cheeseX = parent.YardWidth / 2;
            cheeseY = parent.YardHeight / 2;
        }

    //properties
    public int CheeseX
    {
        get { return cheeseX; }
        set { cheeseX = value; }
    }

    public int CheeseY
    {
        get { return cheeseY; }
        set { cheeseY = value; }
    }

    public int CheeseWidth
    {
        get { return cheeseWidth; }
        set { cheeseWidth = value; }
    }

    public int CheeseHeight
    {
        get { return cheeseHeight; }
        set { cheeseHeight = value; }
    }

    //get boundary
    internal Rectangle GetBoundingBox()
    {
        return new Rectangle(cheeseX, cheeseY, cheeseWidth, cheeseHeight);
    }

    //randomly move cheese
    public void MoveCheese()
    {
        cheeseX = rand.Next(parent.YardWidth);
        cheeseY = rand.Next(parent.YardHeight); ;
    }
}
}
