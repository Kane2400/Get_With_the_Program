﻿using System;
using System.Drawing;

namespace Maze_AI
{
    public class Maze_Hunter
    {
        private int hunterWidth = 20;
        private int hunterHeight = 10;

        private int coordX = 100;
        private int coordY = 100;

        private Random rand = new Random();

        public int CoordX
        {
            get { return coordX; }
            set { coordX = value; }
        }

        public int CoordY
        {
            get { return coordY; }
            set { coordY = value; }
        }

        public int HunterWidth
        {
            get { return hunterWidth; }
            set { hunterWidth = value; }
        }

        public int HunterHeight
        {   
                get { return hunterHeight; }
                set { hunterHeight = value; }
        }

            //get boundary
            internal Rectangle GetBoundingBox()
            {
                return new Rectangle(CoordX, CoordY, HunterWidth, HunterHeight);
            }

            public void Draw(Graphics g)
            {
                //draw the hunter as the yellow rectangle
                g.FillRectangle(new SolidBrush(Color.Yellow), CoordX, CoordY, HunterWidth, HunterHeight);
            }  
            
        
            //randomly move cheese
            public void MoveHunterVertical()
            {
                coordY = rand.Next(50);
                
            }

            public void MoveHunterHorizontal()
            {
                coordX = rand.Next(50);
            }
    }
}