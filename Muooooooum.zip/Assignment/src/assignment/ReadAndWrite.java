package assignment;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Jonny
 */
public abstract class ReadAndWrite 
{

    private ArrayList<String> list;

    private File initializeFile(String filename) 
    {
        File file = new File(filename + ".txt");
        return file;
    }
    
    protected ArrayList<String> read(String fileName) 
    {
        try 
        {
            File temp = initializeFile(fileName);
            Scanner in = new Scanner(temp);
            String line;
            list = new ArrayList<>();
            while (in.hasNextLine()) 
            {
                line = in.nextLine();
                list.add(line);
            }
        } 
        catch (FileNotFoundException e) 
        {
        }
        return list;
    }
    
    protected void write(String filename, ArrayList<String> outputArrayString) 
    {
        try 
        {
            File file = initializeFile(filename);
            PrintWriter print = new PrintWriter(new FileWriter(file));
            for (int i = 0; i < outputArrayString.size(); i++) 
            {
                print.println(outputArrayString.get(i));
            }
            print.close();
        } 
        catch (Exception e) 
        {
        }
    }
}
