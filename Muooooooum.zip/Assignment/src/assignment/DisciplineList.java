package assignment;

/**
 *
 * @author B00716828
 */
import java.io.*;
import java.util.*;

public class DisciplineList {

    //Doctor[] listOfDoc = new Doctor[10];
    private ArrayList<Discipline> disList = new ArrayList<>();
    private ReadAndWriteDiscipline rwd = new ReadAndWriteDiscipline();
    
    

    public DisciplineList() 
    {
        /* for(int i = 0; i < listOfDoc.length; i++ )
       {
         //  listofDoc[i] =                             //may be replaced by populateList
       }*/
    }

    public void addDiscipline(String name, String desc) 
    {
        
        Discipline newDis = new Discipline(name, desc);
        disList.add(newDis);
        this.writeToFile(disList);
    }

    public void removeDiscipline(int index) 
    {
        disList.remove(index);
        this.writeToFile(disList);
    }

    public ArrayList<Discipline> getDisciplineList() 
    {
        ArrayList<Discipline> arrayList = new ArrayList<>();
        arrayList = rwd.readDiscipline(arrayList);
        disList = arrayList;
        return arrayList;
    }
    
    public void writeToFile(ArrayList<Discipline> docList) 
    {
        rwd.writeDoctor(docList);
    }

    /*public void restackAfterRemoveDoc(int numRemove) {
        for (int i = numRemove; i < 9; i++) {
            Doctor temp;
            temp = listOfDoc[i];
            listOfDoc[i - 1] = temp;

        }
        
        
    }*/

}
