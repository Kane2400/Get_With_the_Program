package medicalresourcesystem;

import java.text.*;
import java.util.*;

/**
 *
 * @author Jonny
 */
public class Availability 
{

    private String[][] schedule;
    private String[] doctors;
    private final String[] daysOfTheWeek = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
    private final int NUM_DAYS = daysOfTheWeek.length;
    private String[][] daysRelevant;
    private int numDoctors;

    public Availability() {
        ReadTimetable rt = new ReadTimetable();
        rt.readFromFile();

        int dayNum = 0;
        ArrayList<String> dn = rt.getDocNames();
        ArrayList<String> st = rt.getStartTimes();
        ArrayList<String> et = rt.getEndTimes();
        for (int i = 0; i < daysOfTheWeek.length; i++) 
        {
            if (getDay().equals(daysOfTheWeek[i])) 
            {
                dayNum = i;
                break;
            }
        }
        String[][] daysRelevant = new String[st.size()][2];
        int position = dayNum;
        for (int j = 0; j < dn.size(); j++) 
        {
            daysRelevant[j][0] = st.get(position);
            daysRelevant[j][1] = et.get(position);
            System.out.println(daysRelevant[j][0]);
            System.out.println(daysRelevant[j][1]);
            position += NUM_DAYS;
        }
        
    }

    public String getAvailability(String docname) 
    {
        int docNum = getDocNum(docname);
        if (docNum < numDoctors && docNum >= 0) 
        {
            Date date = new Date();
            DateFormat timeFormat = new SimpleDateFormat("HH:mm");
            try 
            {
                if (timeFormat.parse(getTime()).after(timeFormat.parse(daysRelevant[docNum][0]))
                        && timeFormat.parse(timeFormat.format(date)).before(timeFormat.parse(daysRelevant[docNum][1]))) 
                {
                    // Currently available
                    return "yes";
                } 
                else 
                {
                    // Currently unavailable
                    return "no";
                }
            } 
            catch (ParseException e) 
            {
                // Something went wrong
            }
        }
        return "Error";
    }

    private int getDocNum(String docname) 
    {

        for (int docNum = 0; docNum < numDoctors; docNum++) 
        {
            if (doctors[docNum].equals(docname)) 
            {
                return docNum;
            }
        }
        return numDoctors;
    }

    private String getTime() 
    { // returns the current time to be compared to those stored in the availability update file
        DateFormat timeFormat = new SimpleDateFormat("HH:mm");
        Date time = new Date();
        return timeFormat.format(time);
    }

    private String getDay() 
    { // returns the current day
        DateFormat dayFormat = new SimpleDateFormat("EEEE");
        Date day = new Date();
        return dayFormat.format(day);
    }

    /*public ArrayList<String> getDoctors() 
    {
        return doctors;
    }*/
}
